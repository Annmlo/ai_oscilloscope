---
name: lan-instrument-scpi-toolkit
description: 通用网口仪器（示波器/万用表/电源/信号源/频谱仪）上位机开发工具包。用于发现并识别网段上的仪器、打通 VXI-11 与裸 SCPI Socket 两种 LAN 传输层、探测仪器支持哪些 SCPI 命令、并生成一个可长期运行的 Python 上位机（读循环 + 数据落盘 + 网页界面）。当用户提到示波器、仪器、上位机、SCPI、VXI-11、LXI、网口通讯、*IDN、抓波形、读仪器数据、换一台设备/换品牌（Keysight/Tektronix/Rigol/R&S/LeCroy/Uni-T/普源/鼎阳）重新接入时使用。
agent_created: true
---

# 通用 LAN 仪器 SCPI 上位机工具包

## 这个 skill 解决什么

**不是**某个品牌设备的驱动，而是"拿到一台陌生仪器 → 打通网口 → 生成上位机"的通用流程。
品牌专用细节见 `references/scpi-commands.md` 的差异表；已有设备专用 skill 可作实例参考
（`siglent-scope-access` 就是本流程跑完的成品）。

## 核心心法：先探测，再动手

接陌生仪器，**最忌讳凭印象敲命令**。四个"不知道"必须先用探测消掉：

| 不知道 | 怎么消掉 | 做不到会怎样 |
|---|---|---|
| 对面是谁 | `*IDN?` → 厂商/型号/序列号/固件 | 命令集全猜错 |
| 走哪个端口 | 依次试 5025 → 111 → 4880 → 80 | 连不上就以为设备坏了 |
| 支持哪些命令 | `*OPT?`、探测脚本、手册 | 发 `-113 Undefined header` |
| 数据怎么换算 | 先读 preamble/刻度参数，再读数据 | 波形数值全错、还不报错 |

**顺序不能颠倒**：`*IDN?` 是一切的前提。

## 五步流程

### 第 1 步 · 发现（仪器在哪）

```bash
<python> scripts/discover.py --subnet 192.168.1.0/24
```

无参数则扫描本机所在网段。对每个 IP 探 5025/111/4880/80 端口，通的再发 `*IDN?` 确认。
输出存活仪器清单（IP、端口、IDN、响应耗时）。

> 仪器不在同一网段时先理清本机有几张网卡、IP 分别是多少（脚本会打印）。
> 网络里有多张网卡会让自动发现失效，必须显式指定 `--subnet`。

### 第 2 步 · 连接（走哪条路）

```bash
<python> scripts/probe.py --host 192.168.1.4 --auto
```

按 **5025 → 111 → 4880** 顺序自动尝试，第一个通的即采用。三条路的原理、优劣和
pyvisa 资源串写法见 `references/transport.md`。要点：

- **5025 裸 SCPI**：最轻，纯 socket 即可，传输最快，无依赖
- **111 VXI-11**：最通用，老设备基本都支持；固件常限制**只允许 1 条链接**
- **4880 HiSLIP**：新一代，并发好；老设备没有

### 第 3 步 · 探测能力（能干什么）

`probe.py` 会依次查：`*IDN?` `*OPT?` `*LRN?`（可选）`SYST:ERR?`，并统计
**往返延迟**与**块传输吞吐**（决定上位机能不能做到高帧率）。

示波器再补查：通道列表、时基、采样率、内存深度上限、是否支持标准
`:WAVeform:*` 命令族。命令族探测逻辑见 `references/scpi-commands.md`。

### 第 4 步 · 生成上位机

以 `scripts/scope_app_template.py` 为骨架，按 `references/host-app-architecture.md`
的规范改造。**架构规范比代码更重要**，四条铁律：

1. **只有一个读循环**。所有消费者（网页推送、录制落盘、AI 取数）挂成它的订阅者。
   写第二个读循环 → 抢设备锁 → 两边都掉帧。
2. **落盘在采集进程里**，不要在浏览器/请求线程里做。关掉网页录制仍在继续。
3. **增量 flush**，每 N 帧写一次盘，不要攒到最后（中途崩溃全丢）。
4. **网页只做渲染**。协议用 SSE（单向推流，比 WebSocket 简单，浏览器原生重连）。

### 第 5 步 · 验证（必须真跑，不能只看语法）

1. `py_compile` 语法检查
2. **无设备自检**：`assets/mock_scope.py` 起一个模拟仪器，上位机连它跑通全流程
3. 接真设备跑一遍，对比数据与面板读数是否一致
4. 检查退出路径：`Ctrl+C` / 异常时设备链接是否释放

## 环境事实（这台机器）

| 项 | 值 |
|---|---|
| Python | `D:\00_Tools\09_environments\Python314\python.exe` |
| 已装 | **pyvisa 1.16.2 + pyvisa-py 0.8.1**（VXI-11/HiSLIP/RAW/GPIB/USB/串口全支持） |
| 已装 | numpy 2.5.3、matplotlib 3.11.2 |
| **未装** | pandas、scipy、requests、psutil、zeroconf |
| 缺 psutil 影响 | pyvisa 自动发现只能扫默认网卡 |
| 缺 zeroconf 影响 | 无法用 mDNS 发现 HiSLIP 仪器 |

**未装的库要现装**（走清华镜像）：

```bash
<python> -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple <包名>
```

## 硬性约束（违反必出错）

1. **`HTTP_PROXY` 指向本机代理，会拦截 `127.0.0.1` 请求**。任何本地 HTTP 调用都要
   `urllib.request.build_opener(urllib.request.ProxyHandler({}))`，否则拿到 `502 Bad Gateway`。
   仪器 TCP 通信走原生 socket，不受代理影响。
2. **设备连接是独占资源，多线程访问必须串行化**。两个线程同时用同一条连接收发，
   会让响应错位（A 的查询读到 B 的响应）——实测表现为**采样率读成精确 2 倍**并伴随
   `TimeoutError`。`scpi_client.py` 的两个后端都已内置可重入锁，**多线程共用同一实例是安全的**；
   自己另写客户端必须加锁。更彻底的做法见下一条。
3. **不要从 HTTP/界面线程直接查仪器**。参数要由读循环取好放进快照，界面只读快照
   （`scope_app_template.py` 的 `snapshot_params()` 就是这么做的）。
4. **任何脚本必须 `finally: close()`**。VXI-11 链接不释放 → 设备锁死，后续全连不上。
5. **固件可能只允许 1 条链接**。别同时开两个程序连同一台仪器。
6. **pyvisa-py 的 TCPIP SOCKET 后端读不了二进制块**（实测 0.8.1，关 `termchar_enabled`
   也没用，必 `VI_ERROR_TMO`）。因为它的读循环等终止符，而二进制数据里没有换行。
   **5025 一律用自研 `ScpiSocket`**；`PyvisaClient` 检测到 `::SOCKET` 资源串会自动改用它。
7. **`query_block` 遇到错误响应要快速失败**。仪器回 `-113,"Undefined header"` 时，
   若傻等换行符会耗满超时。`scpi_client.py` 已改成"收到完整文本行却没有 `#` 就立刻抛错"，
   把不支持的命令从 8 秒降到毫秒。自己实现时务必照做。
8. **二进制块是 IEEE 488.2 格式**：`#<k><k位长度><数据>`。必须按声明长度精确读取，
   不能靠 `\n` 判断结束（数据里可能含 `\n`）。
9. **不要假设命令存在**。发命令前先探测或 `try/except`；收到 `-113` 就是命令不支持。
   收命令/查询后都该看一眼 `SYST:ERR?`。
10. **改完参数要清错误队列再判下一条**，否则上一条的 `-113` 会污染下一条的判定。
11. **别用 `time.sleep` 硬等采集**。轮询 `*OPC?`（发 `*OPC`，查询 `*OPC?` 返回 1 表示完成）。
12. **数值解析要容错**。仪器会返回 `2.500MSa`、`1.00E+00V`、`C1:VDIV 2.00E+00V` 等格式，
    统一用 `parse_float()`（见 `scripts/scpi_client.py`），别直接 `float()`。
13. **这台机器的 Git Bash 里 `rm`/`grep`/`head`/`ls`/`dirname` 不可用**，文件操作一律走 Python。
14. `taskkill` 在 Git Bash 下参数会被路径转换破坏 → 用 Python `subprocess`；
    `netstat`/`taskkill` 输出是 **GBK**，要 `decode("gbk","ignore")`。

## 参考文件

| 文件 | 内容 |
|---|---|
| `references/transport.md` | 三种网口传输层原理、端口、pyvisa 资源串、选型决策树 |
| `references/scpi-commands.md` | IEEE488.2 通用命令 + SCPI 子系统 + **六大品牌差异表** |
| `references/host-app-architecture.md` | 上位机架构规范（读循环/订阅/落盘/SSE/反控） |
| `references/handoff-prompt.md` | **给别的 AI 的提示词模板**——想让它帮忙写上位机就复制这个 |
| `scripts/scpi_client.py` | 零依赖通用客户端（TCP-RAW 自实现 + pyvisa 封装） |
| `scripts/discover.py` | 扫描网段找仪器 |
| `scripts/probe.py` | 识别 + 能力探测 + 延迟/吞吐测试 |
| `scripts/scope_app_template.py` | 上位机骨架（复制即改） |
| `assets/mock_scope.py` | 模拟仪器，无硬件也能开发和自检 |
