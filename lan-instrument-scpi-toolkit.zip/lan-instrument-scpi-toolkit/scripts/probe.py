#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
仪器探测 —— 识别 + 能力探测 + 性能测试
=====================================

在写上位机之前跑一遍，回答四个"不知道"：
  ① 对面是谁  ② 走哪个端口  ③ 支持哪些命令  ④ 数据怎么换算

    python probe.py --host 192.168.1.4 --auto
    python probe.py --host 127.0.0.1 --port 5025
    python probe.py --resource "TCPIP0::192.168.1.4::INSTR"

输出一份结构化报告，可直接贴给 AI 让它据此生成上位机。
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scpi_client import (PORT_HISLIP, PORT_SCPI_RAW, PORT_VXI11,  # noqa: E402
                         open_by_resource, open_instrument, parse_float,
                         parse_float_list)

# 波形命令族候选：(族名, 探测命令, 类型, 说明)
#   类型 'block' → 期望 IEEE 488.2 二进制块，用 query_block
#   类型 'text'  → 期望文本参数，用 query
WAVE_FAMILIES = [
    ("标准 SCPI 块  :WAVeform:DATA?", ":WAVeform:DATA?", "block",
     "Keysight / RIGOL / R&S 主线"),
    ("标准 SCPI 参数 :WAVeform:PREamble?", ":WAVeform:PREamble?", "text",
     "换算参数（10 个数）"),
    ("SIGLENT 块    C1:WF? DAT2", "C1:WF? DAT2", "block",
     "SIGLENT SDS 系列"),
    ("SIGLENT 刻度  C1:VDIV?", "C1:VDIV?", "text", "V/div"),
    ("LeCroy 块     C1:WF?", "C1:WF?", "block", "LeCroy 系列"),
    ("Tektronix 块  CURVe?", "CURVe?", "block", "Tek 波形数据"),
    ("Tektronix 参数 WFMOutpre?", "WFMOutpre?", "text", "Tek 换算参数"),
    ("R&S 块        :CHANnel1:DATA?", ":CHANnel1:DATA?", "block", "R&S 通道数据"),
]

# 通用查询候选：命令 → 说明
COMMON_QUERIES = [
    ("SYST:ERR?", "错误队列（0,\"No error\" 为正常）"),
    ("*OPT?", "已装选件"),
    ("ACQuire:SRATe?", "采样率（标准 SCPI）"),
    ("SARA?", "采样率（SIGLENT/LeCroy）"),
    ("TIMebase:SCALe?", "时基（标准 SCPI）"),
    ("TDIV?", "时基（SIGLENT）"),
    ("CHANnel1:SCALe?", "通道1 电压档（标准 SCPI）"),
    ("C1:VDIV?", "通道1 电压档（SIGLENT）"),
]


def hr(ch="─", n=68):
    print(ch * n)


def guess_vendor(idn: str) -> str:
    u = (idn or "").upper()
    if "SIGLENT" in u:
        return "SIGLENT 鼎阳"
    if "KEYSIGHT" in u or "AGILENT" in u:
        return "Keysight 是德"
    if "TEKTRONIX" in u:
        return "Tektronix 泰克"
    if "RIGOL" in u:
        return "RIGOL 普源"
    if "ROHDE" in u or "R&S" in u:
        return "Rohde & Schwarz 罗德"
    if "LECROY" in u:
        return "LeCroy 力科"
    if "UNI-T" in u or "UNIT" in u:
        return "UNI-T 优利德"
    if "GW" in u or "INSTEK" in u:
        return "GW Instek 固纬"
    return "未知"


def probe_families(inst, timeout=2.0) -> list[tuple[str, str, bool, str]]:
    """逐个试波形命令族，返回 [(族名, 命令, 是否支持, 备注)]。

    每条之后清错误队列，避免上一条的 -113 干扰下一条判定。
    注意：query_block 返回的是**已剥掉块头的数据**，所以不能用 '#' 判断，
    成功的判据是"没抛异常且有内容"。
    """
    out = []
    for name, cmd, kind, desc in WAVE_FAMILIES:
        ok, note = False, ""
        try:
            if kind == "block":
                raw = inst.query_block(cmd, timeout=timeout)
                if raw:
                    ok, note = True, "IEEE 块，%d 字节" % len(raw)
                else:
                    note = "空响应"
            else:
                r = (inst.query(cmd, timeout=timeout) or "").strip()
                if r and not re.match(r"\s*-\d", r):
                    ok, note = True, r[:60]
                else:
                    note = r[:50] or "空响应"
        except Exception as e:
            note = type(e).__name__ + (": %s" % str(e)[:40] if str(e) else "")
        out.append((name, cmd, ok, note))
        try:
            inst.check_errors()
        except Exception:
            pass
    return out


def measure_latency(inst, n=20, timeout=3.0) -> float:
    t0 = time.time()
    for _ in range(n):
        inst.query("*IDN?", timeout=timeout)
    return (time.time() - t0) / n * 1000.0


def measure_throughput(inst, cmd: str, timeout=20.0):
    """读一次大块数据，返回 (字节数, 秒, MB/s) 或 None。

    query_block 返回的是已剥掉块头的数据段，len() 即有效载荷字节数。
    """
    try:
        t0 = time.time()
        raw = inst.query_block(cmd, timeout=timeout)
        dt = time.time() - t0
        if raw:
            return len(raw), dt, (len(raw) / dt / 1e6 if dt else 0.0)
    except Exception:
        return None
    return None


def main():
    ap = argparse.ArgumentParser(description="仪器探测：识别 + 能力 + 性能")
    ap.add_argument("--host", help="仪器 IP")
    ap.add_argument("--port", type=int, help="指定端口，不填则自动尝试")
    ap.add_argument("--resource", help="直接用 pyvisa 资源串")
    ap.add_argument("--auto", action="store_true", help="自动按 5025→111→4880 尝试（默认行为）")
    ap.add_argument("--timeout", type=float, default=8.0)
    args = ap.parse_args()

    if not (args.host or args.resource):
        ap.error("需要 --host 或 --resource")

    hr("=")
    print("仪器探测报告")
    hr("=")

    t0 = time.time()
    if args.resource:
        inst = open_by_resource(args.resource, args.timeout)
        target = args.resource
    else:
        try:
            inst = open_instrument(args.host, args.port, args.timeout, verbose=True)
        except RuntimeError as e:
            hr("-")
            print("连接失败：")
            print(e)
            sys.exit(1)
        target = args.host
    connect_s = time.time() - t0

    try:
        # ---------- ① 识别 ----------
        print("\n【① 身份】")
        idn = inst.query("*IDN?", timeout=5.0)
        print("  目标      : %s" % target)
        print("  传输      : %s（建链 %.2fs）" % (inst.kind, connect_s))
        print("  *IDN?     : %s" % idn)
        print("  厂商判断  : %s" % guess_vendor(idn))
        parts = [p.strip() for p in idn.split(",")]
        if len(parts) >= 4:
            print("  ├ 厂商    : %s" % parts[0])
            print("  ├ 型号    : %s" % parts[1])
            print("  ├ 序列号  : %s" % parts[2])
            print("  └ 固件    : %s" % parts[3])
        try:
            print("  *OPT?     : %s" % inst.query("*OPT?", timeout=3.0))
        except Exception as e:
            print("  *OPT?     : 不支持 (%s)" % type(e).__name__)

        # ---------- ② 性能 ----------
        print("\n【② 性能】")
        lat = measure_latency(inst)
        print("  *IDN? 往返延迟 : %.1f ms/次" % lat)

        # ---------- ③ 命令探测 ----------
        print("\n【③ 通用查询探测】")
        for cmd, desc in COMMON_QUERIES:
            try:
                r = inst.query(cmd, timeout=3.0)
                flag = "×" if re.match(r"\s*-?\d*,?\"?.*(Undefined|error)", r or "", re.I) and r.startswith("-") else "√"
                print("  %s %-22s = %-28s  %s" % (flag, cmd, r[:28], desc))
            except Exception as e:
                print("  × %-22s   %-28s  %s" % (cmd, type(e).__name__, desc))

        print("\n【④ 波形命令族探测】")
        fams = probe_families(inst)
        supported = []
        for name, cmd, ok, note in fams:
            print("  %s %-36s %s" % ("√" if ok else "×", name, note))
            if ok:
                supported.append((name, cmd))
        if len(supported) > 1:
            print("  ⓘ 命中多个族是正常的：部分仪器对同义命令都响应。")
            print("    以【① 身份】判断的厂商为准，别用探测结果反推品牌。")

        # ---------- ⑤ 吞吐 ----------
        print("\n【⑤ 块传输吞吐】")
        tp = None
        tp_cmd = None
        for name, cmd in supported:
            if "DAT2" in cmd or "DATA?" in cmd or "CURVe?" in cmd or cmd == "C1:WF?":
                tp_cmd = cmd
                break
        if tp_cmd:
            tp = measure_throughput(inst, tp_cmd)
        if tp:
            print("  探测命令 : %s" % tp_cmd)
            print("  单次读块 : %s 字节 / %.3f s = %.1f MB/s" % ("%d" % tp[0], tp[1], tp[2]))
            est = tp[1] + lat / 1000.0
            if est > 0:
                print("  预估帧率 : 约 %.1f fps（仅采集，不含处理）" % (1.0 / est))
        else:
            print("  未能测出（无可用块命令或超时）")

        # ---------- 错误队列 ----------
        errs = inst.check_errors()
        print("\n【⑥ 错误队列】")
        print("  ", "干净" if not errs else errs)

        # ---------- 结论 ----------
        print("\n【结论】")
        vendor = guess_vendor(idn)
        if "SIGLENT" in vendor:
            print("  命令族   : B 族 —— C1:WF? DAT2 / C1:VDIV? / C1:OFST? / SARA? / TDIV?")
            print("  电压换算 : signed=code-256(>127); V=signed/25*VDIV-OFST")
            print("  时基换算 : t=(i-N/2)/SARA")
        elif "Keysight" in vendor or "RIGOL" in vendor:
            print("  命令族   : A 族 —— :WAV:SOUR/:WAV:FORM BYTE/:WAV:PRE?/:WAV:DATA?")
            print("  电压换算 : V=(raw-yorigin-yreference)*yincrement（用 :WAV:PRE? 第 7/8/9 项）")
        elif "Tektronix" in vendor:
            print("  命令族   : C 族 —— DATA:SOURce/DATA:ENCdg/WFMOutpre?/CURVe?")
            print("  电压换算 : V=(raw-YOFF)*YMULT+YZERO")
        elif "Rohde" in vendor:
            print("  命令族   : :CHANnel<n>:DATA? + :CHANnel<n>:SCALe?/:OFFSet?")
        else:
            print("  未能判断厂商，请查该型号的 Programming Guide")
        print("  下一步   : 把本报告交给 AI，按 references/handoff-prompt.md 模板生成上位机")

    finally:
        inst.close()
        print("\n链接已释放")
        hr("=")


if __name__ == "__main__":
    main()
