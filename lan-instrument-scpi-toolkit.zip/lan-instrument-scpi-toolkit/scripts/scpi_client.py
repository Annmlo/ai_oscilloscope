#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用 LAN 仪器 SCPI 客户端
=========================

零依赖（只用标准库）的裸 SCPI Socket 客户端 + pyvisa 可选后端封装。
两种后端暴露同一套接口，上层代码不关心底层走哪种协议。

    from scpi_client import open_instrument
    inst = open_instrument("192.168.1.4")       # 自动按 5025→111→4880 尝试
    try:
        print(inst.query("*IDN?"))
        codes = inst.query_block("C1:WF? DAT2")
    finally:
        inst.close()                            # ★ 必须，否则设备锁死

命令行自检：
    python scpi_client.py --host 192.168.1.4
    python scpi_client.py --host 127.0.0.1 --port 5025
"""

from __future__ import annotations

import argparse
import re
import socket
import sys
import threading
import time

# 常用端口
PORT_SCPI_RAW = 5025      # 裸 SCPI Socket
PORT_VXI11 = 111          # VXI-11（ONC-RPC portmap）
PORT_HISLIP = 4880        # HiSLIP

# 数值单位前缀
_SI = {
    "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9, "T": 1e12,
    "m": 1e-3, "u": 1e-6, "U": 1e-6, "n": 1e-9, "p": 1e-12,
}


# ---------------------------------------------------------------------------
# 数值 / 二进制块解析（两种后端共用）
# ---------------------------------------------------------------------------
def parse_float(resp: str) -> float:
    """容错解析仪器返回的数值。

    兼容 '2.500MSa'、'5.00E-01V'、'C1:VDIV 2.00E+00V'、'-1.5e-03' 等格式。
    直接 float() 会在带单位后缀时炸掉。
    """
    if resp is None:
        raise ValueError("响应为空")
    m = re.search(
        r"(?<![\w.])[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?\s*([kKMGTmuUnp]?)[a-zA-Z]*",
        str(resp),
    )
    if not m:
        raise ValueError("无法解析数值: %r" % (resp,))
    num = re.match(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", m.group(0))
    return float(num.group(0)) * _SI.get(m.group(1), 1.0)


def parse_float_list(resp: str) -> list[float]:
    """解析一串数值（逗号或空格分隔），逐个走 parse_float。"""
    parts = re.split(r"[,\s]+", (resp or "").strip())
    out = []
    for p in parts:
        if not p:
            continue
        try:
            out.append(parse_float(p))
        except ValueError:
            continue
    return out


def parse_block(raw: bytes) -> bytes:
    """解析 IEEE 488.2 二进制块，返回数据段。

    格式: #<k><k位长度><数据>
      #9000001024<1024 字节>   → k=9，长度=000001024
      #0<数据>                  → 长度不确定，读到终止符为止
    """
    if not raw:
        raise ValueError("空响应")
    i = raw.find(b"#")
    if i < 0:
        raise ValueError("响应里没有 IEEE 488.2 块头: %r" % raw[:60])
    raw = raw[i:]
    k = int(raw[1:2])
    if k == 0:
        return raw[2:].rstrip(b"\r\n")
    if len(raw) < 2 + k:
        raise ValueError("块长度字段不完整")
    n = int(raw[2:2 + k])
    return raw[2 + k:2 + k + n]


def is_error_response(resp: str) -> bool:
    """判断响应是不是 SCPI 错误码（如 '-113,"Undefined header"'）。"""
    return bool(re.match(r"\s*-\d{2,3}\b", resp or ""))


# ---------------------------------------------------------------------------
# 后端 1：裸 SCPI Socket（零依赖）
# ---------------------------------------------------------------------------
class ScpiSocket:
    """裸 TCP SCPI 客户端。只用标准库，无任何第三方依赖。

    ★ 内置线程锁 ★
    仪器连接是**独占资源**：两个线程同时 write/read 会让响应错位
    （A 的查询读到 B 的响应），表现为超时或离谱的数值。
    本类所有公开方法都持锁串行执行，多线程用同一实例是安全的。
    用可重入锁（RLock），所以 query() 内部再调 write()/read() 不会死锁。
    """

    def __init__(self, host: str, port: int = PORT_SCPI_RAW,
                 timeout: float = 8.0, terminator: bytes = b"\n"):
        self.host, self.port = host, port
        self.terminator = terminator
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.settimeout(timeout)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self._buf = b""
        self._lock = threading.RLock()
        self.kind = "SCPI-RAW:%d" % port

    # -- 内部：累积读到满足条件 -------------------------------------------
    def _recv_until(self, predicate, limit: int = 512 * 1024 * 1024) -> bytes:
        while not predicate(self._buf):
            chunk = self.sock.recv(65536)
            if not chunk:
                break                      # 对端关闭
            self._buf += chunk
            if len(self._buf) > limit:
                raise TimeoutError("响应体积超过 %d 字节上限" % limit)
        data, self._buf = self._buf, b""
        return data

    def _recv_exact(self, n: int) -> bytes:
        """精确读 n 字节（用于二进制块数据段）。"""
        while len(self._buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                break
            self._buf += chunk
        data, self._buf = self._buf[:n], self._buf[n:]
        return data

    # -- 公开接口（全部持锁，保证 write+read 原子）--------------------------
    def write(self, cmd: str) -> None:
        with self._lock:
            self.sock.sendall(cmd.encode("ascii", "ignore") + self.terminator)

    def read(self, timeout: float | None = None) -> bytes:
        """读到终止符，返回原始 bytes（不含终止符）。"""
        with self._lock:
            old = self.sock.gettimeout()
            if timeout:
                self.sock.settimeout(timeout)
            try:
                data = self._recv_until(lambda b: b.endswith(self.terminator))
            finally:
                if timeout:
                    self.sock.settimeout(old)
            # 剥掉可能的命令回显（部分仪器会 echo）
            return data.rstrip(b"\r\n")

    def query(self, cmd: str, timeout: float | None = None) -> str:
        with self._lock:
            self.write(cmd)
            return self.read(timeout).decode("ascii", "ignore").strip()

    def _recv_block_head(self) -> bytes:
        """累积直到出现 IEEE 488.2 块头 '#'。

        若先收到**完整的文本行**却不含 '#'（例如仪器回 `-113,"Undefined header"`），
        立即抛错而不是傻等到超时——这一条能把"不支持的命令"从 8 秒超时
        降到毫秒级失败。
        """
        while True:
            if b"#" in self._buf:
                break
            if self._buf.endswith(self.terminator):
                text = self._buf.decode("ascii", "ignore").strip()
                self._buf = b""
                raise ValueError("非二进制块响应: %s" % (text[:80] or "（空）"))
            chunk = self.sock.recv(65536)
            if not chunk:
                text = self._buf.decode("ascii", "ignore").strip()
                self._buf = b""
                raise ValueError("连接关闭，未收到块头: %s" % text[:80])
            self._buf += chunk
        i = self._buf.find(b"#")
        head = self._buf[i:]
        self._buf = b""
        return head

    def query_block(self, cmd: str, timeout: float | None = None) -> bytes:
        """读二进制块，返回数据段（精确按长度读取，不依赖终止符）。"""
        with self._lock:
            self.write(cmd)
            old = self.sock.gettimeout()
            if timeout:
                self.sock.settimeout(timeout)
            try:
                head = self._recv_block_head()
                while len(head) < 2:
                    head += self.sock.recv(64)
                k = int(head[1:2])
                if k == 0:
                    return self._recv_until(lambda b: b.endswith(self.terminator)).rstrip(b"\r\n")
                while len(head) < 2 + k:
                    head += self.sock.recv(64)
                n = int(head[2:2 + k])
                body = head[2 + k:]
                if len(body) < n:
                    body += self._recv_exact(n - len(body))
                return body[:n]
            finally:
                if timeout:
                    self.sock.settimeout(old)

    def query_values(self, cmd: str, datatype: str = "B", timeout: float | None = None):
        """读波形数据并转成整数列表。datatype: 'B'=uint8, 'H'=uint16, 'b'=int8。"""
        raw = self.query_block(cmd, timeout)
        import array
        a = array.array(datatype)
        a.frombytes(raw[:len(raw) - (len(raw) % a.itemsize)])
        return list(a)

    def check_errors(self, max_read: int = 20) -> list[str]:
        """循环读错误队列直到清空（整个循环持锁，避免被插入其它查询）。"""
        with self._lock:
            errs = []
            for _ in range(max_read):
                try:
                    e = self.query("SYST:ERR?", timeout=2.0)
                except Exception:
                    break
                if not e or e.startswith("0,") or e.startswith("0 "):
                    break
                errs.append(e)
            return errs

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


# ---------------------------------------------------------------------------
# 后端 2：pyvisa（支持 VXI-11 / HiSLIP / USB / GPIB / 串口）
# ---------------------------------------------------------------------------
_SOCKET_RES_RE = re.compile(r"^TCPIP\d*::([^:]+)::(\d+)::SOCKET$", re.I)


class PyvisaClient:
    """pyvisa 封装，用于 VXI-11 / HiSLIP / USB / GPIB / 串口。

    ★ 重要实测结论（pyvisa-py 0.8.1）★
    pyvisa-py 的 TCPIP **SOCKET** 后端在读取 IEEE 488.2 二进制块时会一直等待
    终止符，而二进制数据里不含换行 → **必然超时**（VI_ERROR_TMO），关掉
    termchar_enabled 也无效。实测 VXI-11 后端没这个问题（它按 RX_END 判断消息
    结束），自研 ScpiSocket 也没问题。

    因此：检测到 SOCKET 资源串时**自动改用自研 ScpiSocket**，用户不用关心。
    """

    def __init__(self, resource: str, timeout_ms: int = 8000, backend: str = "@py"):
        self.resource = resource
        self._lock = threading.RLock()      # 同 ScpiSocket：设备访问必须串行化
        m = _SOCKET_RES_RE.match(resource.strip())
        if m:
            # 自动接管：SOCKET 走自研实现
            self._impl = ScpiSocket(m.group(1), int(m.group(2)),
                                    timeout=timeout_ms / 1000.0)
            self.inst = None
            self.kind = "SCPI-RAW:%s（socket 资源自动接管）" % m.group(2)
            return

        import pyvisa
        try:
            self.rm = pyvisa.ResourceManager(backend)
        except Exception:
            self.rm = pyvisa.ResourceManager()
        self.inst = self.rm.open_resource(resource)
        self.inst.timeout = timeout_ms
        self._impl = None
        self.kind = "pyvisa:%s" % resource

    def write(self, cmd: str) -> None:
        with self._lock:
            if self._impl:
                return self._impl.write(cmd)
            self.inst.write(cmd)

    def read(self, timeout: float | None = None) -> bytes:
        with self._lock:
            if self._impl:
                return self._impl.read(timeout)
            if timeout:
                self.inst.timeout = int(timeout * 1000)
            return self.inst.read_raw()

    def query(self, cmd: str, timeout: float | None = None) -> str:
        with self._lock:
            if self._impl:
                return self._impl.query(cmd, timeout)
            if timeout:
                self.inst.timeout = int(timeout * 1000)
            return self.inst.query(cmd).strip()

    def query_block(self, cmd: str, timeout: float | None = None) -> bytes:
        with self._lock:
            if self._impl:
                return self._impl.query_block(cmd, timeout)
            if timeout:
                self.inst.timeout = int(timeout * 1000)
            raw = self.inst.query(cmd).encode("latin-1")  # 保留原始字节
            return parse_block(raw)

    def query_values(self, cmd: str, datatype: str = "B", timeout: float | None = None):
        with self._lock:
            if self._impl:
                return self._impl.query_values(cmd, datatype, timeout)
            if timeout:
                self.inst.timeout = int(timeout * 1000)
            return list(self.inst.query_binary_values(cmd, datatype=datatype))

    def check_errors(self, max_read: int = 20) -> list[str]:
        with self._lock:
            if self._impl:
                return self._impl.check_errors(max_read)
            errs = []
            for _ in range(max_read):
                try:
                    e = self.query("SYST:ERR?", timeout=2.0)
                except Exception:
                    break
                if not e or e.startswith("0,") or e.startswith("0 "):
                    break
                errs.append(str(e))
            return errs

    def close(self) -> None:
        with self._lock:
            if self._impl:
                return self._impl.close()
            try:
                self.inst.close()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


# ---------------------------------------------------------------------------
# 端口探测 / 自动连接
# ---------------------------------------------------------------------------
def port_open(host: str, port: int, timeout: float = 0.4) -> bool:
    """TCP 端口是否可连。超时要短，否则扫网段会慢到不可接受。"""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def open_instrument(host: str, port: int | None = None,
                    timeout: float = 8.0, verbose: bool = False):
    """按 5025 → 111 → 4880 顺序尝试，返回第一个可用的客户端。

    port 指定时只用该端口。全部失败抛 RuntimeError，附排查清单。
    """
    def log(*a):
        if verbose:
            print(*a, file=sys.stderr)

    if port:
        candidates = [port]
    else:
        candidates = [PORT_SCPI_RAW, PORT_VXI11, PORT_HISLIP]

    tried = []
    for p in candidates:
        if not port_open(host, p):
            tried.append("%d: 端口不通" % p)
            log("  [x] %s:%d 端口不通" % (host, p))
            continue
        try:
            if p == PORT_VXI11 or p == PORT_HISLIP:
                res = ("TCPIP0::%s::INSTR" % host) if p == PORT_VXI11 \
                    else ("TCPIP0::%s::hislip0::INSTR" % host)
                inst = PyvisaClient(res, timeout_ms=int(timeout * 1000))
            else:
                inst = ScpiSocket(host, p, timeout=timeout)
            idn = inst.query("*IDN?", timeout=min(timeout, 3.0))
            log("  [√] %s:%d → %s" % (host, p, idn))
            return inst
        except Exception as e:
            tried.append("%d: %s" % (p, type(e).__name__))
            log("  [x] %s:%d 连接/识别失败: %s" % (host, p, e))
            continue

    raise RuntimeError(
        "%s 上没找到可用仪器（尝试过 %s）。排查：\n"
        "  1. ping %s 通不通\n"
        "  2. 仪器网口是否启用、IP 是否与电脑同网段\n"
        "  3. 仪器端 SCPI/LAN 接口是否打开\n"
        "  4. 是否已有别的程序占用（部分固件只允许 1 条链接）"
        % (host, "; ".join(tried), host)
    )


def open_by_resource(resource: str, timeout: float = 8.0) -> PyvisaClient:
    """直接用 pyvisa 资源串打开，如 'TCPIP0::192.168.1.4::INSTR' 或 'USB0::...'。"""
    return PyvisaClient(resource, timeout_ms=int(timeout * 1000))


# ---------------------------------------------------------------------------
# 命令行自检
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="通用 SCPI 客户端自检")
    ap.add_argument("--host", help="仪器 IP")
    ap.add_argument("--port", type=int, help="指定端口（不填则自动尝试）")
    ap.add_argument("--resource", help="直接用 pyvisa 资源串")
    ap.add_argument("--timeout", type=float, default=8.0)
    args = ap.parse_args()

    if args.resource:
        inst = open_by_resource(args.resource, args.timeout)
        label = args.resource
    elif args.host:
        t0 = time.time()
        inst = open_instrument(args.host, args.port, args.timeout, verbose=True)
        label = "%s（%s，%.2fs）" % (args.host, inst.kind, time.time() - t0)
    else:
        ap.error("需要 --host 或 --resource")

    try:
        print("=" * 60)
        print("仪器:", label)
        print("=" * 60)
        idn = inst.query("*IDN?")
        print("*IDN?      :", idn)
        for cmd in ("*OPT?", "SYST:VERS?"):
            try:
                print("%-10s :" % cmd, inst.query(cmd, timeout=3.0))
            except Exception as e:
                print("%-10s : 不支持 (%s)" % (cmd, type(e).__name__))

        # 延迟测试
        n, t0 = 10, time.time()
        for _ in range(n):
            inst.query("*IDN?")
        dt = (time.time() - t0) / n
        print("往返延迟    : %.1f ms/次（%d 次平均）" % (dt * 1000, n))

        errs = inst.check_errors()
        print("错误队列    :", errs if errs else "干净")
    finally:
        inst.close()
        print("链接已释放")


if __name__ == "__main__":
    main()
