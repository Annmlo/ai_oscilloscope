#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LAN 仪器发现 —— 扫描网段找出所有可通讯的仪器
============================================

    python discover.py                        # 自动识别本机网段
    python discover.py --subnet 192.168.1.0/24
    python discover.py --subnet 192.168.1.0/24 --ports 5025,111,4880
    python discover.py --hosts 192.168.1.4,192.168.1.5

对每个候选 IP 先探端口（默认 5025 / 111 / 4880），端口通的再发 *IDN? 确认。
只依赖标准库，不需要 psutil / zeroconf。
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import ipaddress
import os
import re
import socket
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scpi_client import (PORT_HISLIP, PORT_SCPI_RAW, PORT_VXI11,  # noqa: E402
                         PyvisaClient, ScpiSocket, port_open)

DEFAULT_PORTS = [PORT_SCPI_RAW, PORT_VXI11, PORT_HISLIP]


# ---------------------------------------------------------------------------
# 本机网络信息
# ---------------------------------------------------------------------------
def primary_ip() -> str | None:
    """拿本机默认出口 IP（不需要真正联网，UDP 不发包）。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return None


def local_ipv4_list() -> list[str]:
    """枚举本机所有 IPv4（Windows 走 ipconfig，其它平台尽力而为）。"""
    ips = set()
    for ip in (_collect_ipconfig(), _collect_getaddrinfo()):
        ips.update(ip)
    if not ips:
        p = primary_ip()
        if p:
            ips.add(p)
    return sorted(ips)


def _collect_ipconfig() -> list[str]:
    if os.name != "nt":
        return []
    try:
        out = subprocess.run(["ipconfig"], capture_output=True, timeout=8)
        txt = out.stdout.decode("gbk", "ignore")
    except Exception:
        return []
    return [m.group(1) for m in re.finditer(r"IPv4[^:]*:\s*([\d.]+)", txt)]


def _collect_getaddrinfo() -> list[str]:
    try:
        host = socket.gethostname()
        return [a[4][0] for a in socket.getaddrinfo(host, None, socket.AF_INET)]
    except Exception:
        return []


def guess_subnet(ip: str, prefix: int = 24) -> str:
    return str(ipaddress.ip_network("%s/%d" % (ip, prefix), strict=False))


# ---------------------------------------------------------------------------
# 单个 IP 探测
# ---------------------------------------------------------------------------
def probe_host(ip: str, ports: list[int], timeout: float = 0.35,
               idn_timeout: float = 2.5) -> dict | None:
    """返回 {'ip','open_ports','idn','kind','port'} 或 None。"""
    open_ports = [p for p in ports if port_open(ip, p, timeout)]
    if not open_ports:
        return None

    # 对每个开放端口试 *IDN?，取第一个成功的
    for p in open_ports:
        inst = None
        try:
            if p in (PORT_VXI11, PORT_HISLIP):
                res = "TCPIP0::%s::INSTR" % ip if p == PORT_VXI11 \
                    else "TCPIP0::%s::hislip0::INSTR" % ip
                inst = PyvisaClient(res, timeout_ms=int(idn_timeout * 1000))
            else:
                inst = ScpiSocket(ip, p, timeout=idn_timeout)
            t0 = time.time()
            idn = inst.query("*IDN?", timeout=idn_timeout)
            dt = (time.time() - t0) * 1000
            if idn and not idn.startswith("-"):
                return {"ip": ip, "open_ports": open_ports, "idn": idn,
                        "kind": inst.kind, "port": p, "idn_ms": dt}
        except Exception:
            pass
        finally:
            if inst:
                inst.close()

    # 有端口开着但不响应 SCPI
    return {"ip": ip, "open_ports": open_ports, "idn": None,
            "kind": None, "port": None, "idn_ms": None}


def scan(hosts: list[str], ports: list[int], workers: int = 64,
         timeout: float = 0.35) -> list[dict]:
    found = []
    t0 = time.time()
    total = len(hosts)
    done = 0
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(probe_host, h, ports, timeout): h for h in hosts}
        for f in cf.as_completed(futs):
            done += 1
            if done % 64 == 0 or done == total:
                pct = done * 100 // max(total, 1)
                print("\r  扫描中 %d/%d (%d%%)  用时 %.1fs  已发现 %d"
                      % (done, total, pct, time.time() - t0, len(found)),
                      end="", file=sys.stderr, flush=True)
            try:
                r = f.result()
            except Exception:
                r = None
            if r:
                found.append(r)
    print("\r" + " " * 70 + "\r", end="", file=sys.stderr)
    return sorted(found, key=lambda x: tuple(int(i) for i in x["ip"].split(".")))


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="扫描网络上的 SCPI 仪器")
    ap.add_argument("--subnet", help="网段，如 192.168.1.0/24")
    ap.add_argument("--hosts", help="逗号分隔的 IP 列表，跳过扫描")
    ap.add_argument("--ports", default=",".join(str(p) for p in DEFAULT_PORTS),
                    help="要探测的端口，默认 5025,111,4880")
    ap.add_argument("--timeout", type=float, default=0.35, help="端口探测超时")
    ap.add_argument("--workers", type=int, default=64, help="并发数")
    ap.add_argument("--all", action="store_true",
                    help="列出所有开着端口的主机（不要求响应 SCPI）")
    args = ap.parse_args()

    ports = [int(x) for x in args.ports.split(",") if x.strip()]

    print("=" * 66)
    print("本机 IPv4:", ", ".join(local_ipv4_list()) or "未知")
    print("=" * 66)

    if args.hosts:
        hosts = [h.strip() for h in args.hosts.split(",") if h.strip()]
        print("目标主机 %d 个，端口 %s" % (len(hosts), ports))
    else:
        subnet = args.subnet
        if not subnet:
            ip = primary_ip()
            if not ip:
                sys.exit("无法确定本机网段，请用 --subnet 指定")
            subnet = guess_subnet(ip)
            print("未指定网段，按默认出口 IP 推断:", subnet)
        net = ipaddress.ip_network(subnet, strict=False)
        hosts = [str(h) for h in net.hosts()]
        print("扫描 %s，共 %d 个地址，端口 %s" % (subnet, len(hosts), ports))

    t0 = time.time()
    print("-" * 66)
    results = scan(hosts, ports, args.workers, args.timeout)
    ok = [r for r in results if r["idn"]]
    raw = [r for r in results if not r["idn"]]
    dt = time.time() - t0

    print("扫描完成：%.1fs，命中 %d 台仪器" % (dt, len(ok)))
    print("=" * 66)
    if ok:
        for r in ok:
            print("  ● %-15s 端口 %-14s  %s"
                  % (r["ip"], ",".join(map(str, r["open_ports"])), r["idn"]))
            print("    %-15s 传输 %s，**IDN 往返 %.1f ms"
                  % ("", r["kind"], r["idn_ms"] or 0))
    else:
        print("  没找到响应 SCPI 的仪器。")

    if args.all and raw:
        print("\n  仅端口开放（未响应 *IDN?）：")
        for r in raw:
            print("    ○ %-15s 端口 %s" % (r["ip"], ",".join(map(str, r["open_ports"]))))

    if not ok:
        print("\n排查建议：")
        print("  1. ping 仪器 IP，确认网络通")
        print("  2. 确认仪器网口已启用、IP 与电脑同网段")
        print("  3. 仪器端 SCPI/LAN 接口是否开启（有些需要手动打开）")
        print("  4. 换 --ports 试其它端口；用 --all 看哪些 IP 有响应")


if __name__ == "__main__":
    main()
