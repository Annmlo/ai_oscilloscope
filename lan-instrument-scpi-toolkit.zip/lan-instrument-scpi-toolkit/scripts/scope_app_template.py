#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用示波器上位机骨架 —— 复制即改
================================

这套骨架是"跨品牌"的：连上仪器后**自动识别命令族**，不用为每个品牌改写。
架构遵循 references/host-app-architecture.md 的四条铁律。

    python scope_app_template.py --host 192.168.1.4            # 网页 + CLI
    python scope_app_template.py --host 127.0.0.1 --port 5025  # 连模拟仪器
    python scope_app_template.py --host 192.168.1.4 --no-web   # 纯命令行
    python scope_app_template.py --host 192.168.1.4 --secs 10  # 抓 10 秒就退出

改造指引：
  · 换品牌 → 什么都不用改，ScopeDriver 自动适配
  · 加分析 → 写个类，在构造里 hub.subscribe(self.on_frame)
  · 加落盘格式 → 照 CsvRecorder 抄
  · 换界面 → 只动 PAGE 和 Handler 的 render 部分，别碰采集层
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import queue
import socket
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
try:
    from scpi_client import open_instrument, parse_float, parse_float_list
except ImportError:
    # 允许把本文件单独复制出去用：退回到同目录查找
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
    from scpi_client import open_instrument, parse_float, parse_float_list


# ===========================================================================
# 配置区（改这里就够）
# ===========================================================================
CFG = {
    "host": "192.168.1.4",
    "port": None,              # None = 自动 5025→111→4880
    "channels": ["C1"],        # 要采集的通道
    "web_port": 8000,
    "out_dir": "records",
    "timeout": 8.0,
    "min_interval": 0.0,       # 帧间隔下限（秒），用于限速；0 = 全速
}


# ===========================================================================
# 第 1 层 · 设备驱动：自动适配不同品牌的命令族
# ===========================================================================
class ScopeDriver:
    """把"不同厂商的不同命令"收敛成统一的 read_wave()。

    两个命令族：
      A 族  标准 SCPI（Keysight / RIGOL / R&S）: :WAVeform:*  + PREamble 换算
      B 族  自有命令（SIGLENT / LeCroy）:        C1:WF? DAT2 + VDIV/OFST 换算
    """

    def __init__(self, inst, log=print):
        self.inst = inst
        self.log = log
        self.family = None
        self.points = 0
        self.sara = 0.0
        self.idn = ""
        self.cache = {}

    # -- 识别 -------------------------------------------------------------
    def identify(self) -> str:
        self.idn = self.inst.query("*IDN?", timeout=5.0)
        self.log("仪器: %s" % self.idn)
        return self.idn

    def detect_family(self) -> str:
        """先按厂商预判，再实测确认。"""
        u = self.idn.upper()
        prefer_b = any(k in u for k in ("SIGLENT", "LECROY"))
        order = ["B", "A"] if prefer_b else ["A", "B"]
        for fam in order:
            probe = "C1:WF? DAT2" if fam == "B" else ":WAVeform:DATA?"
            try:
                raw = self.inst.query_block(probe, timeout=6.0)
                if raw:
                    self.family = fam
                    self.points = len(raw)
                    self.log("命令族: %s 族（探测命令 %s 返回 %d 字节）"
                             % (fam, probe, len(raw)))
                    return fam
            except Exception:
                pass
            try:
                self.inst.check_errors()
            except Exception:
                pass

        # 两步都失败：可能是没开波形传输，退而按厂商猜一个
        self.family = "B" if prefer_b else "A"
        self.log("命令族: 无法实测，按厂商预判为 %s 族（可能有风险）" % self.family)
        return self.family

    # -- 采集参数 ---------------------------------------------------------
    def _q(self, cmd, timeout=3.0):
        try:
            return self.inst.query(cmd, timeout=timeout)
        except Exception:
            return None

    def get_timebase(self):
        """返回 (采样率 Sa/s, 时基 s/div)。"""
        if self.family == "B":
            sara = parse_float(self._q("SARA?") or "0")
            tdiv = parse_float(self._q("TDIV?") or "0")
        else:
            sara = parse_float(self._q(":ACQuire:SRATe?") or "0")
            tdiv = parse_float(self._q(":TIMebase:SCALe?") or "0")
        self.sara = sara
        return sara, tdiv

    def get_channel_scale(self, ch):
        """返回 (V/div, 偏移 V)。"""
        n = ch[-1] if ch.upper().startswith("C") else ch
        if self.family == "B":
            vdiv = parse_float(self._q("%s:VDIV?" % ch) or "0")
            ofst = parse_float(self._q("%s:OFST?" % ch) or "0")
        else:
            vdiv = parse_float(self._q(":CHANnel%s:SCALe?" % n) or "0")
            ofst = parse_float(self._q(":CHANnel%s:OFFSet?" % n) or "0")
        return vdiv, ofst

    # -- 读一帧波形 -------------------------------------------------------
    def read_wave(self, ch):
        """读一个通道，返回 dict(codes, volts, sara, n)。

        ★ 电压换算必须先读参数再算，不要硬编码。★
        """
        if self.family == "B":
            codes = self.inst.query_values("%s:WF? DAT2" % ch, "B")
            vdiv, ofst = self.get_channel_scale(ch)
            volts = [(c - 256 if c > 127 else c) / 25.0 * vdiv - ofst for c in codes]
            sara = self.sara or parse_float(self._q("SARA?") or "1")
        else:
            # A 族：先读 preamble，再读数据
            pre_raw = self._q(":WAVeform:PREamble?") or ""
            pre = parse_float_list(pre_raw)
            codes = self.inst.query_values(":WAVeform:DATA?", "B")
            if len(pre) >= 10:
                xinc, yinc, yorg, yref = pre[4], pre[7], pre[8], pre[9]
                volts = [(c - yorg - yref) * yinc for c in codes]
                sara = 1.0 / xinc if xinc else 0.0
            else:
                vdiv, ofst = self.get_channel_scale(ch)
                volts = [(c - 256 if c > 127 else c) / 25.0 * vdiv - ofst for c in codes]
                sara = self.sara
        return {"ch": ch, "codes": codes, "volts": volts, "sara": sara,
                "n": len(codes)}


# ===========================================================================
# 第 2 层 · 唯一读循环
# ===========================================================================
class ReaderHub(threading.Thread):
    """全局唯一读循环。所有消费者以订阅者身份挂上来。"""

    daemon = True

    def __init__(self, driver: ScopeDriver, channels, min_interval=0.0, log=print):
        super().__init__(name="ReaderHub")
        self.driver = driver
        self.channels = channels
        self.min_interval = min_interval
        self.log = log
        self._subs = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.frame_count = 0
        self.last_error = None
        self.fps = 0.0
        self._t_hist = []
        self.params = {}                    # 参数快照，只由读循环更新

    def subscribe(self, fn):
        with self._lock:
            self._subs.append(fn)

    def unsubscribe(self, fn):
        with self._lock:
            if fn in self._subs:
                self._subs.remove(fn)

    def stop(self):
        self._stop.set()

    def _refresh_params(self):
        """只有读循环可以调它（设备访问必须串行）。"""
        try:
            sara, tdiv = self.driver.get_timebase()
            self.params = {"sara": sara, "tdiv": tdiv, "idn": self.driver.idn,
                           "family": self.driver.family}
        except Exception as e:
            self.log("刷新参数失败: %s" % e)

    def snapshot_params(self):
        """★ 只读缓存，绝不在这里访问设备 ★

        从 HTTP 线程直接查询仪器会与读循环争夺同一条连接，
        导致响应错位（实测：采样率被读成 2 倍、并伴随 TimeoutError）。
        """
        p = dict(self.params)
        p.setdefault("idn", self.driver.idn)
        p.setdefault("family", self.driver.family)
        return p

    def run(self):
        while not self._stop.is_set():
            t0 = time.time()
            try:
                waves = {ch: self.driver.read_wave(ch) for ch in self.channels}
                self.frame_count += 1
                # 首帧和之后每 50 帧刷新一次参数（参数很少变）
                if self.frame_count == 1 or self.frame_count % 50 == 0:
                    self._refresh_params()
                f = {
                    "frame": self.frame_count,
                    "t_iso": datetime.now().isoformat(timespec="milliseconds"),
                    "t_elapsed_s": round(t0 - _START, 3),
                    "waves": waves,
                    "sara": next(iter(waves.values()))["sara"] if waves else 0.0,
                    "fps": self.fps,
                }
                with self._lock:
                    subs = list(self._subs)
                for fn in subs:
                    try:
                        fn(f)
                    except Exception as e:
                        self.log("订阅者异常: %s" % e)
            except Exception as e:
                self.last_error = "%s: %s" % (type(e).__name__, e)
                self.log("采集异常: %s" % self.last_error)
                time.sleep(0.5)
                continue

            dt = time.time() - t0
            self._t_hist.append(dt)
            if len(self._t_hist) > 30:
                self._t_hist.pop(0)
            self.fps = 1.0 / (sum(self._t_hist) / len(self._t_hist))
            if self.min_interval > dt:
                time.sleep(self.min_interval - dt)


# ===========================================================================
# 第 3 层 · 落盘（增量 flush，浏览器关掉也继续）
# ===========================================================================
FRAME_COLS = ["t_iso", "t_elapsed_s", "frame", "ch", "n_points", "sara_sa_s",
              "vpp_v", "vmax_v", "vmin_v", "vmean_v"]


class CsvRecorder:
    """把每帧的统计量写成标量表，另存最后一帧的逐点数据。"""

    def __init__(self, hub: ReaderHub, out_dir: str, log=print):
        os.makedirs(out_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        self.frames_path = os.path.join(out_dir, "record_%s_frames.csv" % stamp)
        self.points_path = os.path.join(out_dir, "record_%s_points.csv" % stamp)
        self.log = log
        self.n = 0
        self.t_start = time.time()
        self._f = open(self.frames_path, "w", newline="", encoding="utf-8-sig")
        self._w = csv.writer(self._f)
        self._w.writerow(FRAME_COLS)
        self._f.flush()
        self._pf = open(self.points_path, "w", newline="", encoding="utf-8-sig")
        self._pw = csv.writer(self._pf)
        self._pw.writerow(["frame", "ch", "idx", "t_s", "V"])
        self._pf.flush()
        hub.subscribe(self.on_frame)
        self.log("开始录制 → %s" % self.frames_path)

    def on_frame(self, f):
        try:
            for ch, w in f["waves"].items():
                v = w["volts"]
                if not v:
                    continue
                self._w.writerow([
                    f["t_iso"], f["t_elapsed_s"], f["frame"], ch, w["n"],
                    "%.6g" % w["sara"], "%.6g" % (max(v) - min(v)),
                    "%.6g" % max(v), "%.6g" % min(v),
                    "%.6g" % (sum(v) / len(v)),
                ])
            self.n += 1
            if self.n % 10 == 0:            # ★ 每 10 帧真正落盘
                self._f.flush()
                os.fsync(self._f.fileno())
        except Exception as e:
            self.log("录制写入异常: %s" % e)

    def dump_last_frame(self, f):
        """把某一帧的逐点数据写成独立文件（供离线分析）。"""
        for ch, w in f["waves"].items():
            sara = w["sara"] or 1.0
            n = w["n"]
            for i, v in enumerate(w["volts"]):
                self._pw.writerow([f["frame"], ch, i,
                                   "%.9g" % ((i - n / 2.0) / sara), "%.6g" % v])
        self._pf.flush()
        os.fsync(self._pf.fileno())

    def stop(self):
        try:
            self._f.close()
            self._pf.close()
        except Exception:
            pass
        self.log("录制结束：%d 帧 → %s" % (self.n, self.frames_path))
        return {"frames": self.n, "frames_file": self.frames_path,
                "points_file": self.points_path}


# ===========================================================================
# 第 4 层 · 网页（只做渲染；不碰采集）
# ===========================================================================
PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>示波器上位机</title>
<style>
  body{margin:0;font:13px/1.5 system-ui,"Microsoft YaHei",sans-serif;
       background:#11161d;color:#dfe7ef}
  header{padding:10px 16px;background:#1a2230;display:flex;gap:16px;
         align-items:center;border-bottom:1px solid #2a3648;flex-wrap:wrap}
  h1{font-size:15px;margin:0;font-weight:600}
  .pill{padding:2px 9px;border-radius:10px;background:#22304a;font-size:12px}
  .ok{color:#4ade80}.bad{color:#f87171}
  button{padding:5px 12px;border:1px solid #33445f;border-radius:5px;
         background:#22304a;color:#dfe7ef;cursor:pointer;font-size:12px}
  button:hover{background:#2b3d59}
  main{padding:14px 16px;display:grid;grid-template-columns:1fr 320px;gap:14px}
  canvas{width:100%;height:320px;background:#0b1017;border:1px solid #2a3648;
         border-radius:6px}
  .card{background:#161d28;border:1px solid #2a3648;border-radius:6px;padding:10px}
  .kv{display:flex;justify-content:space-between;padding:3px 0;
      border-bottom:1px solid #1f2836}
  .kv:last-child{border:none}
  .k{color:#8b9bb4}
  table{width:100%;border-collapse:collapse;font-size:12px}
  td{padding:3px 6px;border-bottom:1px solid #1f2836;font-variant-numeric:tabular-nums}
  .hi{color:#fbbf24}.lo{color:#60a5fa}
</style></head><body>
<header>
  <h1>示波器上位机</h1>
  <span class="pill" id="idn">连接中…</span>
  <span class="pill" id="fam">-</span>
  <span class="pill" id="fps">- fps</span>
  <span class="pill" id="frames">0 帧</span>
  <button id="rec">● 开始录制</button>
  <span class="pill" id="recst">空闲</span>
</header>
<main>
  <div>
    <canvas id="cv" width="1000" height="320"></canvas>
    <div class="card" style="margin-top:12px">
      <table id="tbl"></table>
    </div>
  </div>
  <div class="card" id="stats"></div>
</main>
<script>
const $ = s => document.querySelector(s);
let last = null, frameNo = 0, recording = false;

function drawWave(cv, volts, color, minV, maxV){
  const ctx = cv.getContext('2d'), W = cv.width, H = cv.height, P = 10;
  ctx.fillStyle = '#0b1017'; ctx.fillRect(0,0,W,H);
  // 网格
  ctx.strokeStyle = '#1a2330'; ctx.lineWidth = 1;
  for(let i=1;i<10;i++){ ctx.beginPath();
    ctx.moveTo(P+i*(W-2*P)/10, P); ctx.lineTo(P+i*(W-2*P)/10, H-P); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(P, P+i*(H-2*P)/10); ctx.lineTo(W-P, P+i*(H-2*P)/10); ctx.stroke(); }
  if(!volts || !volts.length) return;
  const span = (maxV-minV) || 1;
  ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.beginPath();
  for(let i=0;i<volts.length;i++){
    const x = P + i*(W-2*P)/(volts.length-1);
    const y = H-P - (volts[i]-minV)/span*(H-2*P);
    i ? ctx.lineTo(x,y) : ctx.moveTo(x,y);
  }
  ctx.stroke();
}
function render(f){
  if(!window._cv){ window._cv = $('#cv'); }
  const cv = $('#cv');
  const waves = f.waves; const chs = Object.keys(waves);
  if(!chs.length) return;
  let all = [];
  chs.forEach(c => all = all.concat(waves[c].volts));
  const minV = Math.min(...all), maxV = Math.max(...all);
  // 最多画 2000 点，避免卡顿
  const w0 = waves[chs[0]];
  let vs = w0.volts;
  if(vs.length > 2000){ const st = Math.ceil(vs.length/2000);
    vs = vs.filter((_,i)=> i%st===0); }
  const colors = {C1:'#fbbf24', C2:'#60a5fa', CHAN1:'#fbbf24', CHAN2:'#60a5fa'};
  drawWave(cv, vs, colors[chs[0]] || '#fbbf24', minV, maxV);
  // 表格：每通道一行
  let html = '<tr><td class="k">通道</td><td class="k">点数</td>'+
             '<td class="k">Vpp</td><td class="k">Vmax</td><td class="k">Vmin</td></tr>';
  chs.forEach(c => { const v = waves[c].volts;
    const mx = Math.max(...v), mn = Math.min(...v);
    html += `<tr><td>${c}</td><td>${waves[c].n}</td>
      <td>${(mx-mn).toFixed(3)}</td><td class="hi">${mx.toFixed(3)}</td>
      <td class="lo">${mn.toFixed(3)}</td></tr>`; });
  $('#tbl').innerHTML = html;
  // 统计卡
  $('#stats').innerHTML =
    `<div class="kv"><span class="k">帧号</span><span>${f.frame}</span></div>
     <div class="kv"><span class="k">时间</span><span>${f.t_iso.split('T')[1]}</span></div>
     <div class="kv"><span class="k">采样率</span><span>${(f.sara/1e6).toFixed(3)} MSa/s</span></div>
     <div class="kv"><span class="k">已运行</span><span>${f.t_elapsed_s} s</span></div>`;
}

function connect(){
  const es = new EventSource('/api/stream');
  es.onmessage = ev => {
    const f = JSON.parse(ev.data);
    last = f; frameNo = f.frame;
    render(f);
    $('#fps').textContent = (f.fps||0).toFixed(2) + ' fps';
    $('#frames').textContent = f.frame + ' 帧';
  };
  es.onerror = () => { $('#idn').textContent = '重连中…'; };
}
fetch('/api/params').then(r=>r.json()).then(p=>{
  $('#idn').textContent = p.idn || '-';
  $('#fam').textContent = p.family + ' 族';
});
$('#rec').onclick = async () => {
  const url = recording ? '/api/rec/stop' : '/api/rec/start';
  const r = await fetch(url, {method:'POST'});
  const d = await r.json();
  recording = !recording;
  $('#rec').textContent = recording ? '■ 结束录制' : '● 开始录制';
  $('#recst').textContent = recording ? ('录制中 ' + (d.frames_path||'').split(/[\\/]/).pop())
                                      : ('已存 ' + (d.frames||0) + ' 帧');
};
connect();
</script></body></html>
"""


class Handler(BaseHTTPRequestHandler):
    hub: ReaderHub = None
    recorder: CsvRecorder = None
    driver: ScopeDriver = None
    lock = threading.Lock()

    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            body = PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/params":
            p = self.hub.snapshot_params()
            p["channels"] = list(self.hub.channels)
            p["fps"] = self.hub.fps
            p["frame"] = self.hub.frame_count
            p["error"] = self.hub.last_error
            self._json(p)
        elif self.path == "/api/stream":
            self._stream()
        else:
            self._json({"error": "not found"}, 404)

    def _stream(self):
        """SSE：有界队列，慢客户端丢帧但不拖累采集。"""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        q = queue.Queue(maxsize=4)
        dropped = [0]

        def sink(f):
            try:
                q.put_nowait(f)
            except queue.Full:
                dropped[0] += 1

        self.hub.subscribe(sink)
        try:
            while True:
                try:
                    f = q.get(timeout=10)
                except queue.Empty:
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                    continue
                payload = {"frame": f["frame"], "t_iso": f["t_iso"],
                           "t_elapsed_s": f["t_elapsed_s"], "sara": f["sara"],
                           "fps": f["fps"], "waves": {}}
                for ch, w in f["waves"].items():
                    vs = w["volts"]
                    if len(vs) > 2000:      # ★ 只推视口需要的点数
                        st = max(1, len(vs) // 2000)
                        vs = vs[::st]
                    payload["waves"][ch] = {"n": w["n"], "volts": vs}
                self.wfile.write(b"data: " +
                                 json.dumps(payload, ensure_ascii=False).encode() + b"\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            self.hub.unsubscribe(sink)      # ★ 必须退订

    def do_POST(self):
        if self.path == "/api/rec/start":
            with self.lock:
                if self.recorder is None:
                    self.recorder = CsvRecorder(self.hub, CFG["out_dir"])
                    Handler.recorder = self.recorder
                    self._json({"ok": True, "frames_path": self.recorder.frames_path})
                else:
                    self._json({"ok": False, "error": "已在录制中"})
        elif self.path == "/api/rec/stop":
            with self.lock:
                if self.recorder is None:
                    self._json({"ok": False, "error": "没有在录制"})
                else:
                    self.hub.unsubscribe(self.recorder.on_frame)
                    info = self.recorder.stop()
                    Handler.recorder = None
                    self._json(dict(ok=True, **info))
        else:
            self._json({"error": "not found"}, 404)


# ===========================================================================
_START = time.time()


def main():
    ap = argparse.ArgumentParser(description="通用示波器上位机骨架")
    ap.add_argument("--host", help="仪器 IP")
    ap.add_argument("--port", type=int, help="指定端口，不填自动尝试")
    ap.add_argument("--resource", help="直接用 pyvisa 资源串")
    ap.add_argument("--chs", default="C1", help="通道，逗号分隔，如 C1,C2")
    ap.add_argument("--web-port", type=int, default=CFG["web_port"])
    ap.add_argument("--out", default=CFG["out_dir"], help="录制输出目录")
    ap.add_argument("--secs", type=float, default=0,
                    help="抓 N 秒后自动退出（0=一直跑）")
    ap.add_argument("--no-web", action="store_true", help="不开网页，只打印")
    ap.add_argument("--record", action="store_true", help="启动即开始录制")
    args = ap.parse_args()

    if not (args.host or args.resource):
        ap.error("需要 --host 或 --resource（试一试 127.0.0.1 --port 5025 配合 mock_scope.py）")

    CFG["out_dir"] = args.out
    channels = [c.strip().upper() for c in args.chs.split(",") if c.strip()]

    # 1) 连接
    if args.resource:
        from scpi_client import open_by_resource
        inst = open_by_resource(args.resource, CFG["timeout"])
    else:
        inst = open_instrument(args.host, args.port, CFG["timeout"], verbose=True)

    try:
        # 2) 识别 + 适配
        driver = ScopeDriver(inst)
        driver.identify()
        driver.detect_family()
        sara, tdiv = driver.get_timebase()
        print("采样率 %.6g Sa/s ｜ 时基 %.6g s/div ｜ 通道 %s"
              % (sara, tdiv, ",".join(channels)))

        # 3) 起读循环（先把参数灌进快照，网页一打开就有值）
        hub = ReaderHub(driver, channels, CFG["min_interval"])
        hub.params = {"sara": sara, "tdiv": tdiv, "idn": driver.idn,
                      "family": driver.family}
        hub.start()
        time.sleep(0.5)
        if hub.last_error:
            print("首次采集有问题：%s" % hub.last_error)

        # 4) 录制
        recorder = None
        if args.record:
            recorder = CsvRecorder(hub, CFG["out_dir"])

        # 5) 网页
        srv = None
        if not args.no_web:
            Handler.hub = hub
            Handler.driver = driver
            srv = ThreadingHTTPServer(("127.0.0.1", args.web_port), Handler)
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            print("网页: http://127.0.0.1:%d" % args.web_port)

        # 6) 主循环（CLI 统计 / 定时退出）
        print("采集中…（Ctrl+C 停止）")
        t_end = time.time() + args.secs if args.secs else None
        last_n = 0
        try:
            while True:
                time.sleep(1.0)
                print("\r  帧 %d ｜ %.2f fps ｜ 已跑 %.1fs   "
                      % (hub.frame_count, hub.fps, time.time() - _START),
                      end="", flush=True)
                if t_end and time.time() >= t_end:
                    break
                if hub.frame_count == last_n and hub.last_error:
                    print("\n  采集停滞：%s" % hub.last_error)
                last_n = hub.frame_count
        except KeyboardInterrupt:
            print()

        # 7) 收尾
        print()
        hub.stop()
        hub.join(timeout=3)
        if recorder:
            info = recorder.stop()
            print("已保存: %s" % info["frames_file"])
    finally:
        inst.close()                    # ★ 必须释放设备
        print("设备链接已释放")


if __name__ == "__main__":
    main()
