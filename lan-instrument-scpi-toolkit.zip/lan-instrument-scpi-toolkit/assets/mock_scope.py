#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
模拟示波器（Mock Scope）—— 无硬件也能开发和自检
================================================

开一个真 TCP 5025 端口，说真 SCPI，吐真 IEEE 488.2 二进制块。
上位机连它就能跑通全流程，硬件到位后只改 IP 即可。

    python mock_scope.py                       # 监听 0.0.0.0:5025
    python mock_scope.py --port 5026 --duty 0.6
    python mock_scope.py --points 20480 --sara 250000

然后上位机连 127.0.0.1:5025 就行。

模拟内容：
  *IDN?              → 假 IDN（默认 SIGLENT 风格，--brand keysight 切标准 SCPI 风格）
  C1:WF? DAT2        → C1 波形（8 位 ADC 码，IEEE 488.2 块）
  C2:WF? DAT2        → C2 波形
  :WAV:DATA?         → 标准 SCPI 风格波形
  :WAV:PRE?          → 标准 10 参数 preamble
  C1:VDIV? / C1:OFST? / TDIV? / SARA?
  SYST:ERR? / *OPC? / *IDN? / *RST / *CLS
  其余命令           → 记录到 stderr 并返回 -113（模拟不支持）
"""

from __future__ import annotations

import argparse
import math
import socketserver
import sys
import threading
import time


class MockState:
    """模拟仪器状态 + 波形生成。"""

    def __init__(self, brand="siglent", points=20480, sara=250_000.0,
                 freq=124.38, duty=0.5, vpp=3.08, vdiv=1.0, ofst=0.0,
                 depth_words=None):
        self.brand = brand
        self.points = points
        self.sara = sara
        self.freq = freq
        self.duty = duty          # 可用 --duty-sweep 让它动起来
        self.vpp = vpp
        self.vdiv = vdiv
        self.ofst = ofst
        self.running = True
        self.cls_count = 0
        self.t0 = time.time()
        self.lock = threading.Lock()

    # -- 波形：8 位无符号 ADC 码（真实仪器就是这样传的）-------------------
    def codes(self, ch=1):
        n = self.points
        dt = 1.0 / self.sara
        # 让占空比缓慢变化，模拟"扫描"，也便于分析脚本验证漂移逻辑
        with self.lock:
            duty = self.duty
        period = 1.0 / self.freq
        out = bytearray(n)
        # 高电平码 / 低电平码：按 vdiv=1V、25 码/格换算
        amp_codes = self.vpp / self.vdiv * 25.0
        lo_code = 5.0
        hi_code = min(255.0, lo_code + amp_codes)
        for i in range(n):
            t = i * dt
            phase = (t % period) / period
            v = hi_code if phase < duty else lo_code
            # 加一点量化噪声（±1 码），模拟真实 ADC
            jitter = 0.0 if (i % 7) else 1.0
            c = int(round(v + jitter))
            out[i] = max(0, min(255, c))
        if ch == 2:
            # C2 空通道：只有量化噪声
            return bytes((5 + (i % 2)) & 0xFF for i in range(n))
        return bytes(out)

    def preamble(self):
        """标准 SCPI 的 :WAVeform:PREamble? 10 个参数"""
        xinc = 1.0 / self.sara
        xorg = -(self.points / 2.0) / self.sara
        # yincrement = vdiv / 25（每码对应电压）
        yinc = self.vdiv / 25.0
        return [0, 0, self.points, 1, xinc, xorg, 0, yinc, 0.0, 0.0]


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        st = self.server.state
        peer = self.client_address
        print("[mock] 客户端接入 %s:%d" % peer, file=sys.stderr)
        try:
            while True:
                line = self.rfile.readline()
                if not line:
                    break
                cmd = line.decode("ascii", "ignore").strip()
                if not cmd:
                    continue
                resp = self.dispatch(cmd, st)
                if resp is not None:
                    if isinstance(resp, bytes):
                        self.wfile.write(resp)
                    else:
                        self.wfile.write(resp.encode("ascii", "ignore") + b"\n")
                    self.wfile.flush()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            print("[mock] 客户端断开 %s:%d" % peer, file=sys.stderr)

    # -- 命令分发 --------------------------------------------------------
    def dispatch(self, cmd, st):
        u = cmd.upper()
        is_query = cmd.endswith("?")

        # --- IEEE 488.2 通用 ---
        if u == "*IDN?":
            if st.brand == "keysight":
                return "KEYSIGHT TECHNOLOGIES,DSOX1204G,CN12345678,02.11.20220101"
            if st.brand == "tek":
                return "TEKTRONIX,TBS1102B,SN123456,CXYY"
            return "Siglent Technologies,SDS1102CNL+,SN-MOCK-0001,6.01.01.20"
        if u == "*OPT?":
            return "0"
        if u == "*OPC?":
            return "1"
        if u in ("*OPC", "*CLS", "*RST", "*WAI"):
            if u == "*CLS":
                st.cls_count += 1
            return None
        if u in ("SYST:ERR?", "SYSTEM:ERROR?"):
            return '0,"No error"'
        if u == "*ESR?":
            return "0"

        # --- 波形数据（SIGLENT 风格 B 族）---
        for ch in (1, 2):
            if u in ("C%d:WF? DAT2" % ch, "C%d:WF?" % ch):
                return self.block(st.codes(ch))
            if u == "C%d:VDIV?" % ch:
                return "%.2fE+00" % st.vdiv
            if u == "C%d:OFST?" % ch:
                return "%.2fE+00" % st.ofst
            if u == "C%d:TRA?" % ch:
                return "ON" if st.running else "OFF"

        # --- 波形数据（标准 SCPI A 族）---
        if u.startswith(":WAV:DATA?") or u.startswith(":WAVEFORM:DATA?"):
            src = self.last_source if hasattr(self, "last_source") else "CHAN1"
            ch = 2 if "2" in src else 1
            return self.block(st.codes(ch))
        if u.startswith(":WAV:PRE") or u.startswith(":WAVEFORM:PRE"):
            return ",".join(repr(x) if isinstance(x, float) else str(x)
                            for x in st.preamble())
        if u.startswith(":WAV:SOUR") and is_query:
            return getattr(self, "last_source", "CHAN1")
        if ":SOUR" in u and not is_query:
            self.last_source = cmd.split()[-1].upper()
            return None
        if u.startswith(":WAV:FORM") and is_query:
            return "BYTE"
        if u.startswith(":WAV:POIN") and is_query:
            return str(st.points)

        # --- 时基 / 采样 ---
        if u in ("TDIV?", ":TIM:SCAL?"):
            # 10 格覆盖整屏：s/div = 总窗口 / 10
            return "%.2E" % (st.points / st.sara / 10.0)
        if u in ("SARA?", ":ACQ:SRAT?"):
            return "%.3fMSa" % (st.sara / 1e6)

        # --- 控制类 ---
        if u in (":RUN", "RUN"):
            st.running = True
            return None
        if u in (":STOP", "STOP"):
            st.running = False
            return None
        if u in (":SING", "SINGLE"):
            return None
        if u in (":AUTOSET EXECUTE", "ASET", ":ASET"):
            return None

        # --- 不支持 ---
        print("[mock] 不支持的命令: %s" % cmd, file=sys.stderr)
        if is_query:
            return '-113,"Undefined header"'
        return None

    @staticmethod
    def block(data: bytes) -> bytes:
        """打包成 IEEE 488.2 块：#<k><k位长度><数据>"""
        n = len(data)
        s = str(n)
        return b"#" + str(len(s)).encode() + s.encode() + data


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    ap = argparse.ArgumentParser(description="模拟示波器")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5025)
    ap.add_argument("--brand", default="siglent",
                    choices=("siglent", "keysight", "tek"))
    ap.add_argument("--points", type=int, default=20480)
    ap.add_argument("--sara", type=float, default=250_000.0)
    ap.add_argument("--freq", type=float, default=124.38)
    ap.add_argument("--duty", type=float, default=0.5)
    ap.add_argument("--vpp", type=float, default=3.08)
    args = ap.parse_args()

    state = MockState(brand=args.brand, points=args.points, sara=args.sara,
                      freq=args.freq, duty=args.duty, vpp=args.vpp)

    srv = Server((args.host, args.port), Handler)
    srv.state = state
    print("模拟示波器已启动：%s:%d" % (args.host, args.port))
    print("  IDN     : %s" % state.brand)
    print("  点数/采样: %d @ %.0f Sa/s" % (state.points, state.sara))
    print("  信号    : %.2f Hz, 占空比 %.1f%%, Vpp %.2f V"
          % (state.freq, state.duty * 100, state.vpp))
    print("  上位机连 127.0.0.1:%d 即可。Ctrl+C 退出。" % args.port)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n停止")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
