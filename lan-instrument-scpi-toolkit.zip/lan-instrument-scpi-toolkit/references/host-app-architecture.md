# 上位机架构规范

> 这份规范来自一个真实跑起来的项目：SIGLENT SDS1102CNL+ 网页控制台（单通道
> 20480 点 @250kSa/s 稳定 4.4 fps，双通道 2.4 fps）。踩过的坑都写在这里了。

## 一、四层结构

```
┌─────────────────────────────────────────────────┐
│ 第 4 层  网页 / CLI / 分析脚本                     │
│  只做渲染和取数，不含任何业务逻辑                    │
├─────────────────────────────────────────────────┤
│ 第 3 层  HTTP 服务器（路由 + SSE 推流）            │
│  /api/stream  /api/params  /api/ctrl  /api/record │
├─────────────────────────────────────────────────┤
│ 第 2 层  ReaderHub  ★唯一读循环★                  │
│  采集 → 广播给所有订阅者                            │
│    ├─ SSE 订阅者（推给浏览器）                      │
│    ├─ Recorder 订阅者（落盘 CSV）                  │
│    └─ 计算订阅者（FFT、统计，放后台线程）            │
├─────────────────────────────────────────────────┤
│ 第 1 层  设备驱动（SCPI 客户端 + 全局锁）           │
│  唯一的设备会话，所有命令串行化                      │
└─────────────────────────────────────────────────┘
```

**分层的意义**：网页关掉不影响录制；FFT 算得慢不影响采集；换设备只动第 1 层。

## 二、铁律 1：只有一个读循环

### 为什么

设备固件往往**只允许 1 条 VXI-11 链接**，且物理链路吞吐有限。
两个读循环 = 抢设备锁 = 各分一半帧率，还会互相把对方的响应读走（响应错位）。

### 推论：设备访问必须串行化 + 参数走快照

"只有一个读循环"还不够。**任何一个别的线程都不该碰设备**，哪怕只是查个采样率。

真实踩坑记录：网页的 `/api/params` 接口从 HTTP 线程直接发 `SARA?` 查询，
而读循环同时在发 `C1:WF? DAT2`。结果：

- 采样率被读成 **520480**（真实 250000，**精确的 2 倍** —— 响应错位导致
  读到了两次查询之间错位的数据）
- 读循环开始报 `TimeoutError: timed out`
- 界面显示的数字离谱但**不报错**，最难排查

修法两层，都要做：

```python
# 第 1 层：客户端内置可重入锁，保证 write+read 原子
class ScpiSocket:
    def __init__(self, ...):
        self._lock = threading.RLock()      # RLock 让 query() 内部再调 write() 不死锁

    def query(self, cmd, timeout=None):
        with self._lock:
            self.write(cmd)
            return self.read(timeout)

# 第 2 层：界面只读读循环维护的快照，自己绝不碰设备
class ReaderHub:
    def run(self):
        ...
        if self.frame_count == 1 or self.frame_count % 50 == 0:
            self._refresh_params()          # 读循环里刷，安全

    def snapshot_params(self):
        return dict(self.params)            # 纯内存读，零设备访问
```

**诊断信号**：看到数值"精确成倍"或"看起来合理但就是不对"，先怀疑并发抢占连接。

### 怎么做

```python
class ReaderHub(threading.Thread):
    """全局唯一读循环：采集一帧 → 广播给所有订阅者"""
    daemon = True

    def __init__(self):
        super().__init__()
        self._subs = []          # 订阅者列表
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.frame_count = 0

    def subscribe(self, fn):
        with self._lock:
            self._subs.append(fn)

    def unsubscribe(self, fn):
        with self._lock:
            if fn in self._subs:
                self._subs.remove(fn)

    def run(self):
        while not self._stop.is_set():
            t0 = time.time()
            try:
                f = self._grab_one_frame()      # 唯一一处调用设备
            except Exception as e:
                self._on_error(e)
                time.sleep(0.5)
                continue
            self.frame_count += 1
            f["frame"] = self.frame_count
            f["t_iso"] = datetime.now().isoformat(timespec="milliseconds")
            with self._lock:
                subs = list(self._subs)
            for fn in subs:
                try:
                    fn(f)                        # 订阅者自己保证不阻塞
                except Exception:
                    pass                         # 一个订阅者挂了不能拖累别人
            # 限速：帧率上限可配
            dt = time.time() - t0
            if dt < self._min_interval:
                time.sleep(self._min_interval - dt)
```

### 新功能怎么挂

**不要**新建线程去连设备。**要**写个 sink 挂上去：

```python
class MyAnalyzer:
    def __init__(self, hub):
        hub.subscribe(self.on_frame)
    def on_frame(self, f):
        # 只做轻量处理，重活扔队列给别的线程
        ...
```

## 三、铁律 2&3：落盘在采集侧 + 增量 flush

### 为什么

- 浏览器关掉 → 录制必须继续 → 落盘不能依赖网页
- 攒到最后再写 → 中途崩溃全丢 / 内存爆炸

### 怎么做

```python
class Recorder:
    def __init__(self, hub, out_dir, stride=1):
        self.f = open(frames_csv, "w", newline="", encoding="utf-8-sig")
        self.w = csv.writer(self.f)
        self.w.writerow(HEADER)
        self.n = 0
        hub.subscribe(self.on_frame)

    def on_frame(self, f):
        self.w.writerow(build_row(f))
        self.n += 1
        if self.n % 10 == 0:        # ★ 每 10 帧 flush 一次
            self.f.flush()
            os.fsync(self.f.fileno())   # 真正落盘，防断电丢失
```

### 逐点大文件的处理

逐点数据（每帧 2 万行）写入会拖慢读循环。用**独立写线程 + 有界队列**，
队列满了就丢最旧的（宁可丢点也不要拖慢采集）：

```python
class PointsWriter(threading.Thread):
    daemon = True
    def __init__(self, path):
        super().__init__()
        self.q = queue.Queue(maxsize=16)     # 有界！
        ...
    def offer(self, rows):
        try:
            self.q.put_nowait(rows)
        except queue.Full:
            self.dropped += 1                 # 记下来，别静默丢
```

### 落盘前先同步一次参数

录制开始瞬间，硬件参数可能还没读回来 → 前几帧参数列为空。
**录制器启动时同步读一次参数**（`seed()`），别等订阅的第一帧。

## 四、铁律 4：网页只做渲染

### SSE 而不是 WebSocket

单向推流用 **SSE**（Server-Sent Events）就够，优点是**浏览器原生自动重连**，
不用自己写心跳。波形推送、参数刷新都走 SSE。

```python
def do_GET(self):
    if self.path.startswith("/api/stream"):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        q = queue.Queue(maxsize=4)          # 有界：慢客户端不拖累采集
        def sink(f):
            try:
                q.put_nowait(f)
            except queue.Full:
                pass                        # 丢帧，不阻塞
        HUB.subscribe(sink)
        try:
            while True:
                try:
                    f = q.get(timeout=10)
                except queue.Empty:
                    self.wfile.write(b": ping\n\n")   # 保活
                    continue
                self.wfile.write(b"data: " + json.dumps(f).encode() + b"\n\n")
                self.wfile.flush()
        finally:
            HUB.unsubscribe(sink)           # ★ 必须退订
```

### 帧率统计（用户最关心）

要区分三个数，别混：

| 指标 | 含义 |
|---|---|
| **读循环帧率** | 设备实际采了多少帧 |
| **推送帧率** | 网络/浏览器收到多少 |
| **渲染帧率** | 页面真的画了多少 |

三者差距大说明瓶颈在中间环节（通常是浏览器 canvas 绘制）。

### 原始数据表只渲染视口

上千行表格全量塞 DOM 会卡死。**只渲染当前滚动位置的窗口**，或提供"显示点数"下拉。

## 五、反控（网页操作仪器）

三个必须做的：

1. **命令白名单**。别把网页传来的字符串直接发给设备：
   ```python
   ALLOWED = {"run", "stop", "single", "autoset", "trmd", "ch1", "ch2", ...}
   if cmd not in ALLOWED:
       return {"error": "未知命令"}
   ```
2. **状态机要记住"上一次的模式"**。例如 STOP 之后固件会把触发模式改成 STOP，
   单纯发 "ARM/单次" 是恢复不了的 → **必须记住停机前的模式，Run 时恢复它**。
3. **参数变化后立刻失效缓存**（VDIV/OFST 这类被缓存的值要重读）。

## 六、配置项与状态分离

- **配置**（IP、端口、内存深度、存储路径）→ 常量或配置文件，启动时读一次
- **状态**（当前通道、时基、运行状态）→ 从设备实时读，不缓存过夜
- **用户数据**（录像、截图）→ 统一目录 + `latest.json` 索引，带中文列说明

落盘目录建议结构：

```
recordings/
  record_20260919_125804_frames.csv    # 标量表（每帧一行）
  record_20260919_125804_points.csv    # 逐点表（每点一行，可能上百 MB）
  latest.json                          # 索引 + 列中文说明
```

**文件名要自解释**。别用 `record_x.csv` / `record_x_wave.csv` 这种，
用户会打开错文件（真实踩过）。用 `_frames` / `_points` 明确区分。

## 七、启动与关闭

```python
def main():
    dev = open_device(IP)             # 建立唯一会话
    HUB = ReaderHub(dev)
    HUB.start()
    srv = ThreadingHTTPServer(("127.0.0.1", 8000), Handler)
    try:
        srv.serve_forever()
    finally:
        HUB.stop()
        HUB.join(timeout=3)
        dev.close()                   # ★ 一定要释放设备
```

**重启流程**（Windows）：

```python
import subprocess
out = subprocess.run(["netstat", "-ano"], capture_output=True).stdout.decode("gbk", "ignore")
pid = [l.split()[-1] for l in out.splitlines() if ":8000" in l and "LISTENING" in l]
for p in set(pid):
    subprocess.run(["taskkill", "/F", "/PID", p])
```

> Git Bash 下直接调 `taskkill` 参数会被路径转换破坏 → 必须用 Python `subprocess`。
> `netstat` 输出是 GBK，要 `decode("gbk","ignore")`。

## 八、无设备开发

**不要等硬件就绪才开始写**。`assets/mock_scope.py` 起一个模拟仪器（真开 5025 端口、
说 SCPI、会吐 IEEE 488.2 块），上位机连它就能跑通全流程、验证协议解析、压力测试。

硬件到位后只需把 IP 从 `127.0.0.1` 改成真机地址。
