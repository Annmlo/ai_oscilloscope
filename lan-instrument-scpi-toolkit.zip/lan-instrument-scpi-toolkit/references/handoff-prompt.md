# 把任务交给别的 AI —— 提示词模板

## 怎么用

1. 把整个 `lan-instrument-scpi-toolkit` 目录（或打包好的 zip）一起给 AI
2. 从下面挑一个模板，把 `【】` 里的内容换成你的实际情况
3. 发给 AI，让它按 skill 里的流程做

**核心原则**：不要让 AI 一上来就写代码。**先探测，再写**。
所以模板分两轮：第一轮探测，第二轮开发。

---

## 轮次 1 · 探测（必做，别跳过）

```
你有一个 instrument skill 工具包（见附件/skill 目录），里面讲的是通过网口
用 SCPI 协议与仪器通讯的通用方法。请先读 SKILL.md 和 references/ 下的文档。

现在我有一台仪器要接入：
- 型号：【写型号，不确定就写"不确定"】
- IP：【写 IP，不确定就写"不确定"】
- 我的电脑网段：【如 192.168.1.x，不确定就写"不确定"】

请你先只做探测，不要写上位机：
1. 用 scripts/discover.py 扫描找到仪器
2. 用 scripts/probe.py 识别它、确认走哪个端口（5025 / 111 / 4880）
3. 报告：*IDN? 内容、支持的传输层、往返延迟、块传输吞吐
4. 试探它支持哪套波形命令族（标准 :WAVeform:* / C1:WF? / CURVE?）
5. 报告探测中遇到的错误和你的判断

探测完把结果列成表给我看，等我确认后再进入开发。
```

---

## 轮次 2 · 生成上位机

```
基于上一轮的探测结果，请生成一个 Python 上位机。

【环境】
- Python：D:\00_Tools\09_environments\Python314\python.exe（3.14）
- 已装：pyvisa 1.16.2、pyvisa-py 0.8.1、numpy、matplotlib
- 未装：pandas、scipy、requests（要用就告诉我，我走清华镜像装）
- 参考实现：另一个项目里的 sds_pro_server.py 是同类成品，架构可借鉴

【需求】
- 功能：【抓波形 / 实时曲线 / 录制落盘 / 反控仪器 / 出报告 …】
- 通道：【C1 / C1+C2 / 通道1,2,3,4】
- 帧率要求：【尽量快 / 稳定 N 帧每秒】
- 界面：【网页 / 命令行 / 无界面】
- 数据要存成：【CSV / NPZ / …】，存到【目录】

【硬性要求】（照着 skill 里的 host-app-architecture.md 做）
1. 全局只有一个读循环，其它功能挂成订阅者
2. 落盘在采集进程里，浏览器/终端关掉也继续录
3. 增量 flush，每 N 帧写一次
4. 网页只做渲染，用 SSE 推流
5. 所有设备操作包 try/except，最终 finally close()
6. 数值解析要容错（仪器会返回 2.500MSa 这种带单位的）
7. 用 assets/mock_scope.py 先做无设备自检，再接真机

【交付】
- 一个可以直接 python xxx.py 跑起来的文件（或多个文件）
- 告诉我怎么启动、怎么验证、怎么重启
- 如果有做不到的部分，明确说出来，不要假装能做
```

---

## 轮次 3 · 复盘与排障

出问题时用：

```
上位机跑起来了但有这个问题：【描述现象，贴报错】

环境事实：
- 仪器：【型号 / IP】
- 传输层：【5025 / VXI-11 / HiSLIP】
- Python：D:\00_Tools\09_environments\Python314\python.exe
- 已装库：【列出】

请按 skill 里的排障思路定位：
1. 先确认是 网络 / 传输层 / 命令集 / 换算 / 应用逻辑 哪一层的问题
2. 给出可执行的验证步骤（命令或最小脚本）
3. 定位到根因后再改代码

注意：不要靠猜。每条结论都要有实测证据支撑。
```

---

## 给 AI 的补充说明（如果它不熟悉仪器通讯）

把这段话一起发过去，能省很多来回：

```
关于仪器通讯的几个要点，请务必遵守：

1. **先 *IDN? 确认型号**，再决定用哪套命令。不同品牌甚至同品牌不同系列的
   波形读取命令完全不同（Keysight 用 :WAV:DATA?，SIGLENT 用 C1:WF?，
   Tektronix 用 CURVE?）。猜命令只会得到 -113 Undefined header。

2. **端口要按 5025 → 111 → 4880 顺序试**。不是所有仪器都开了 5025。
   有的老设备只有 VXI-11（111 端口，走 ONC-RPC，不是直接连 111 就完事）。

3. **VXI-11 链接必须释放**。固件常常只允许 1 条链接，泄漏一条之后所有
   程序都连不上，只能重启仪器。任何脚本都要 finally close()。

4. **二进制波形是 IEEE 488.2 块**：#<k><k位长度><数据>。必须按声明长度
   精确读取，不能用换行符判断结束（数据里可能有换行字节）。

5. **电压换算要先读参数再算**。标准 SCPI 是 :WAVeform:PREamble? 返回 10 个数，
   V = (raw - yorigin - yreference) * yincrement。SIGLENT 是
   V = signed(code)/25 * VDIV - OFST。**先读参数，不要硬编码**。

6. **不是所有数据都能从仪器读**。比如 SIGLENT 读 FFT 波形返回 -113，
   这种情况要在电脑端用原始采样自己算（numpy + Hann 窗 + dBVrms）。

7. **命令失败要查错误队列** SYSTEM:ERROR? / SYST:ERR?，返回
   0,"No error" 才是正常。不要靠"命令没报异常"判断成功。

8. **调试顺序**：先 mock 后真机；先 *IDN? 后复杂命令；
   先小数据量后大数据量。
```

---

## 打包发送

把 skill 目录压缩成一个 zip 发出去最省事：

```python
import shutil, os
src = r"C:\Users\test01\.workbuddy\skills\lan-instrument-scpi-toolkit"
dst = r"D:\lan-instrument-scpi-toolkit"
shutil.make_archive(dst, "zip", os.path.dirname(src), os.path.basename(src))
# → D:\lan-instrument-scpi-toolkit.zip
```

对方 AI 只要能读文件（或能读你粘贴的 SKILL.md 正文）就能照做。
现代 AI 基本都能直接理解 Markdown 说明 + 跟着写代码。
