# 网口传输层：三种协议 + 选型决策

## 总览

仪器走网口有三种方式，物理上都是 **TCP/IP**，区别在**上层怎么封装消息**。同一台仪器
可能三种都开，也可能只开一种。

| | 裸 SCPI Socket | VXI-11 | HiSLIP |
|---|---|---|---|
| 标准 | 无（厂商约定俗成） | VXI-11 (VXIbus 规范) | IVI HiSLIP |
| 端口 | **5025** | **111**（RPC portmap，实际数据端口动态分配） | **4880** |
| 底层 | 裸 TCP | ONC-RPC / XDR | TCP + 自有握手 |
| 依赖 | 无，`socket` 即可 | 需要 RPC 实现（pyvisa-py 内置） | 同左 |
| 速度 | **最快**（开销最小） | 中（每次调用有 RPC 往返） | 快（有异步/并发通道） |
| 并发 | 单客户端（一般不限制但设备处理不过来） | **固件常限制 1 条链接** | 支持多通道 |
| 年代 | 2000s 起流行 | 老，1990s | 新，2010s |
| 常见品牌 | 几乎全部 | 几乎全部 | 新机型 |

## 1) 裸 SCPI Socket（推荐首选）

**原理**：仪器开一个 TCP 端口（惯例 5025），把 SCPI 文本当字节流收发。

- 发送：`命令 + "\n"`（少数仪器要 `"\r\n"`）
- 响应：读到 `"\n"` 为止
- 二进制块：`#<k><k位长度><数据>`，按长度精确读，**不能**等 `\n`

**代码要点**：

```python
s = socket.create_connection((host, 5025), timeout=8)
s.sendall(b"*IDN?\n")
# 必须累积读到换行，一次 recv 可能只拿到半个响应
```

**坑**：
- 有的仪器**回显命令**（把 `*IDN?` 也发回来），要先剥掉
- 大块数据（几十 MB 波形）要循环 recv，且缓冲区要足够
- 没有"设备清空"标准语义，出错后可能残留半个响应污染下一次查询
- 遇到错误响应（`-113`）时，如果按"等换行符"读就耗满超时；
  **要识别"收到完整文本行却不含块头 `#`"并立即失败**（见 `scpi_client.py`）

### ★ 实测警告：别用 pyvisa-py 走 SOCKET 读波形 ★

**pyvisa-py 0.8.1 的 TCPIP SOCKET 后端读不了 IEEE 488.2 二进制块**——
它的读循环会一直等待终止符，而二进制数据里没有换行，结果必然
`VI_ERROR_TMO`。实测把 `termchar_enabled` 关掉也无效，因为问题在
pyvisa-py 的 `select` 读循环里，不在 termination 属性上。

已验证的对照事实：

| 方式 | 文本查询 | 读二进制块 |
|---|---|---|
| 自研 `ScpiSocket` | √ | **√ 20480 点 / 3 ms** |
| pyvisa-py `::SOCKET` | √ | **× 必超时** |
| pyvisa-py VXI-11（`::INSTR`） | √ | √（按 RX_END 判消息结束，无此问题） |

**结论：5025 一律用自研 `ScpiSocket`。** `scpi_client.py` 的 `PyvisaClient`
识别到 `::SOCKET` 资源串时会**自动改用它**，所以直接把资源串交给它也不会踩坑。

## 2) VXI-11（老设备兜底）

**原理**：基于 **ONC-RPC**（Sun RPC）。流程：

```
客户端 → 111端口 portmap 查 "device core channel" 的服务端口
       → 建 RPC 连接到该端口
       → create_link   (建立设备链接，拿到 lid)
       → device_write  (发命令)
       → device_read   (读响应)
       → destroy_link  (释放)
```

**三个必须知道的点**：

1. **必须 `destroy_link`**，否则链接泄漏。固件通常**只允许 1 条**链接，
   泄漏一条之后所有程序都连不上，只能重启仪器。
2. **RPC 端口是动态的**，不是 111。111 只是"查号台"。
3. 有个 **abort 通道**用于中断长操作，pyvisa-py 已封装，不用自己管。

**用 pyvisa-py 走 VXI-11**（不用自己写 RPC）：

```python
rm = pyvisa.ResourceManager("@py")
inst = rm.open_resource("TCPIP0::192.168.1.4::INSTR")   # 不写端口就是 VXI-11
```

> 想用 `python-vxi11` 包则是 `vxi11.Instrument(host)`，接口更简单，但要额外装包。
> **本项目曾遇到 5025 未开、只有 VXI-11 可用的设备**（SIGLENT SDS1102CNL+），
> 所以 VXI-11 这条路必须保留。

## 3) HiSLIP（新设备）

端口 4880，有 "synchronous" 和 "asynchronous" 两条逻辑通道。pyvisa 资源串：

```python
rm.open_resource("TCPIP0::192.168.1.4::hislip0::INSTR")
```

一般在 5025/111 都可用时才轮到它，优先级最低。

## pyvisa 资源串语法速查

格式：`<接口>::<主机>::<...>::INSTR` 或 `...::SOCKET`

| 目标 | 资源串 |
|---|---|
| VXI-11（默认 INSTR） | `TCPIP0::192.168.1.4::INSTR` |
| 裸 SCPI Socket 5025 | `TCPIP0::192.168.1.4::5025::SOCKET` |
| 裸 SCPI 其它端口 | `TCPIP0::192.168.1.4::5025::SOCKET` → 改端口号即可 |
| HiSLIP | `TCPIP0::192.168.1.4::hislip0::INSTR` |
| USB TMC | `USB0::0xF4EC::0xEE38::SN12345::INSTR` |
| 串口 | `ASRL3::INSTR` |
| GPIB | `GPIB0::5::INSTR` |

**搜网络仪器**（需要 psutil 才能扫全部网卡）：

```python
rm.list_resources("?*")     # '?*' 触发网络发现，比 list_resources() 慢但能找到网口设备
```

## 选型决策树

```
能 ping 通吗？
├─ 否 → 查网段/网线/仪器 IP 设置，先解决网络
└─ 是 → 依次探端口：
     ├─ 5025 通 → 【用它】最快、最稳、代码最简单
     ├─ 111  通 → 用 VXI-11（注意 close）
     ├─ 4880 通 → 用 HiSLIP
     └─ 都不通 → 只开了 Web(80)。看是不是要通过 web API
                （部分仪器 LXI 支持 HTTP 上的 SCPI，路径各异，需查手册）
```

**端口探测代码**（`discover.py` 已实现）：

```python
def port_open(host, port, timeout=0.4):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False
```

## 不能忽略的工程细节

### 超时
- **连接超时**要短（0.3~1s），否则扫网段慢到无法接受
- **读超时**要按数据量给（读 20 MB 波形给 10~30s，读 `*IDN?` 给 2s）
- pyvisa：`inst.timeout = 5000`（毫秒）

### 采样一致性
读完一组配置再去读数据，中间别插入其它命令——仪器状态可能被别的客户端改动。
**要读多个相关参数时，尽量连着读完**。

### 错误处理
每次操作后建议查一次错误队列：

```python
err = q("SYST:ERR?")   # 返回 "0,\"No error\"" 表示正常
```

### 大数据量
波形动辄几 MB 到几百 MB。要点：
- 用 `query_binary_values(datatype="B")` 直接拿数组，别当字符串
- 传输格式尽量选 **BYTE**（1 字节/点）而不是 ASCII（~7 字节/点）
- 见过某设备 `MATH:WF?` 返回 `-113`（不支持）→ 说明**不是所有数据都能从仪器拿**，
  该在电脑端算的（如 FFT）就在电脑端算
