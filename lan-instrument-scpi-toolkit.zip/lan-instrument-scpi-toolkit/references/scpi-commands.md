# SCPI 命令集与品牌差异

> 前提：**先 `*IDN?` 确认型号，再照下表选命令族。** 别拿 Keysight 的命令去捅 Tektronix。

## 一、IEEE 488.2 通用命令（所有仪器都该支持）

| 命令 | 作用 | 备注 |
|---|---|---|
| `*IDN?` | 识别：厂商,型号,序列号,固件 | **第一件事**。返回用逗号分隔 |
| `*OPT?` | 已装选件 | 有些返回 `0` 表示无 |
| `*RST` | 复位到出厂默认 | 会改变所有设置，慎用 |
| `*CLS` | 清状态寄存器 + 清错误队列 | 出错后收拾局面 |
| `*OPC` / `*OPC?` | 操作完成标志 / 查询是否完成 | `*OPC` 发出后 `*OPC?` 读到 `1` 即完成 |
| `*WAI` | 等待前面操作做完 | 阻塞式，会卡住读超时 |
| `*ESR?` | 标准事件状态寄存器 | 查"发生过什么" |
| `SYST:ERR?` | **错误队列**（SCPI 层，非 488.2） | 返回 `code,"message"`，`0,"No error"` 正常 |
| `SYST:VERS?` | SCPI 版本 | 少见 |
| `*LRN?` | 回读完整设置状态 | 有些仪器不支持，响应可达数 KB |

**读错误队列要循环读到 0**，因为队列可能积压多条：

```python
while True:
    e = q("SYST:ERR?").strip()
    if e.startswith("0") or not e:
        break
    errs.append(e)
```

## 二、示波器：两套命令族

**这是换品牌最大的坑**——示波器波形读取有两套完全不同的命令风格。

### A 族 · 标准 SCPI 波形（Keysight / Rigol / R&S / 多数新机）

```scpi
:WAVeform:SOURce CHANnel1      # 选源
:WAVeform:FORMat BYTE          # 传输格式：BYTE(1B/点) / WORD(2B) / ASCii
:WAVeform:BYTeorder LSBFirst   # WORD 时才有意义
:WAVeform:POINts 10000         # 点数，或 MAXimum
:WAVeform:POINts:MODE RAW      # RAW(内存原始) / NORMal(屏幕)
:WAVeform:PREamble?            # ★ 换算参数（10 个数）
:WAVeform:DATA?                # 波形数据（IEEE 488.2 块）
```

**`:WAVeform:PREamble?` 返回这 10 个数**（顺序固定，务必按此解析）：

| # | 含义 |
|---|---|
| 0 | format（0=BYTE, 1=WORD, 4=ASCII） |
| 1 | type（0=normal, 1=peak, 2=avg, 3=hres） |
| 2 | points（点数） |
| 3 | count（平均次数） |
| 4 | **xincrement**（相邻点时间间隔，s） |
| 5 | **xorigin**（第一个点的时间，s） |
| 6 | xreference（触发点在记录里的索引） |
| 7 | **yincrement**（每个 ADC 码对应电压，V） |
| 8 | **yorigin**（y 轴原点） |
| 9 | yreference（y 轴参考） |

**电压换算（A 族通用公式）**：

```
V[i] = (raw[i] - yorigin - yreference) * yincrement
t[i] = xorigin + xreference * xincrement + i * xincrement
```

> 简化常见写法：`V = (raw - yref) * yinc`、`t = xorg + i * xinc`。
> 严格版含 yorigin，**以仪器实际返回为准**——先读 preamble 再算，别硬编码。

### B 族 · 厂商自有命令（SIGLENT 等）

SIGLENT SDS 系列（`C1:WF?` 风格）：

```scpi
C1:WF? DAT2                    # 读 C1 的 DAT2 段（8 位 ADC 码）
C1:VDIV?                       # V/div
C1:OFST?                       # 通道偏移
TDIV?                          # 时基
SARA?                          # 采样率
C1:WFSU SP,0,NP,<n>,FP,0       # 波形设置：无稀疏、n 点、起点 0
```

**换算（B 族 SIGLENT）**：

```
signed = code - 256 if code > 127 else code       # 8 位有符号
V = signed / 25.0 * VDIV - OFST                    # 每格 25 码
t = (i - N/2) / SARA                               # 中点为 0
```

**已知限制**：`MATH:WF?`（FFT/MATH 波形）返回 `-113 Undefined header`，
**读不出来**。FFT 必须在电脑端用原始采样自算（Hann 窗 + 转 dBVrms）。

### C 族 · Tektronix（又是另一套）

```scpi
DATA:SOUrce CH1
DATA:ENCdg RIBINARY            # 或 ASCII / RPBINARY / SRIbinary
WFMOutpre?                     # 或 WFMPRE?（用 :WFMPRE? 老命令）
CURVe?                         # 波形数据
```

关键参数名不同：`YMULT`（增益）、`YOFF`（偏移）、`YZERO`（零点）、`XINCR`、`XZERO`、`PT_OFF`。
换算：`V = (raw - YOFF) * YMULT + YZERO`。

## 三、六大品牌差异表

| 品牌 | IDN 首字段 | 波形命令 | 换算参数 | 二进制块 |
|---|---|---|---|---|
| **SIGLENT** 鼎阳 | `Siglent` | `C1:WF? DAT2` | `C1:VDIV?` `C1:OFST?` `SARA?` | IEEE 488.2 |
| **Keysight** 是德 | `Keysight Technologies` | `:WAV:DATA?` | `:WAV:PRE?` 10 参数 | IEEE 488.2 |
| **Tektronix** 泰克 | `TEKTRONIX` | `CURVE?` | `WFMOUTPRE?` YMULT/YOFF/YZERO | IEEE 488.2 |
| **RIGOL** 普源 | `RIGOL` | `:WAV:DATA?` | `:WAV:PRE?` 与 Keysight 同构 | IEEE 488.2 |
| **R&S** 罗德 | `Rohde&Schwarz` | `:CHAN:DATA?` | `:CHAN:SCAL?` `:CHAN:OFFS?` | IEEE 488.2 |
| **LeCroy** 力科 | `LECROY` | `C1:WF?` | `C1:VDIV?` `C1:OFST?` | 自有格式，需查手册 |

> 前三列只是**最常见写法**，同品牌不同系列仍可能不同。**永远以该型号的
> Programming Guide 为准**，探测脚本只能给出可能性。

## 四、按"想干什么"组织的命令索引

### 通用（万用表/电源/信号源也适用）

```scpi
SYST:ERR?                       # 错误队列
*IDN?  *RST  *CLS  *OPC?        # 基础控制
```

### 示波器

| 目的 | 命令 |
|---|---|
| 通道开关 | `CHANnel1:DISPlay ON` / SIGLENT: `C1:TRA ON` |
| 电压档位 | `CHANnel1:SCALe 1.0` / `C1:VDIV 1.0` |
| 垂直偏移 | `CHANnel1:OFFSet 0` / `C1:OFST 0` |
| 耦合 | `CHANnel1:COUPling DC\|AC\|GND` |
| 时基 | `TIMebase:SCALe 1e-3` / `TDIV 0.001` |
| 触发模式 | `TRIGger:SWEep AUTO\|NORMal\|SINGle` / `TRMD AUTO\|NORM\|SING` |
| 触发电平 | `TRIGger:LEVel 1.5` / `C1:TRLV 1.5` |
| 触发沿 | `TRIGger:EDGe:SLOPe POSitive\|NEGative` |
| 自动设置 | `:AUTOSet EXECute` / `ASET` |
| 采样率查询 | `ACQuire:SRATe?` / `SARA?` |
| 内存深度 | `ACQuire:POINts 100000`（**深度越大帧率越低**） |
| 运行/停止 | `:RUN` / `:STOP` |
| 单次触发 | `:SINGle` |
| 硬件测量 | `MEASure:VPP? CHAN1` / `C1:PAVA? PKPK` |
| 屏幕截图 | `:DISPlay:DATA?` / SIGLENT: `SCDP`（**返回裸 BMP，不是 IEEE 块**） |

### 万用表

```scpi
MEASure:VOLTage:DC?             # 读直流电压
CONFigure:VOLTage:DC 10         # 配置量程
SAMPle:COUNt 10                 # 采样数
```

### 电源

```scpi
APPLy CH1,5.0,1.0               # 通道1 设 5V/1A
MEASure:VOLTage? CH1
OUTPut CH1,ON
```

### 信号源

```scpi
FREQuency 1000
VOLTage:AMPLitude 2.0
OUTPut ON
```

## 五、命令探测策略（不知支持什么时）

**不要一次发一堆命令**（会积累一堆 `-113` 噪音）。逐条试探 + 查错误队列：

```python
CANDIDATES = [
    ":WAVeform:PREamble?",      # 标准 SCPI 波形
    "C1:WF? DAT2",              # SIGLENT 风格
    "WFMOutpre?",               # Tektronix 风格
]

for cmd in CANDIDATES:
    try:
        write(cmd)
        r = read_raw(timeout=2)
        if r and not r.startswith("-"):     # 不以负错误码开头
            print("支持:", cmd, "→", r[:80])
    except Exception as e:
        print("不支持:", cmd, type(e).__name__)
    # 每条之后清错误队列，避免干扰下一条
```

## 六、二进制块格式（IEEE 488.2）

```
#9000001024<1024 字节数据>
 ││└────────┘
 │└ 长度位数 k（此处 9）
 └ 固定 '#'
```

- `#0` 表示"长度不确定，读到终止符为止"（少见但要处理）
- `#8` 表示长度占 8 位
- **必须按声明的字节数精确读取**，数据里可能有 `\n`

```python
def parse_block(buf):
    assert buf[0:1] == b'#'
    k = int(buf[1:2])
    if k == 0:
        return buf[2:]                       # 读终止符模式
    n = int(buf[2:2+k])
    return buf[2+k:2+k+n]
```

## 七、性能调优（影响帧率）

按收益排序：

1. **传输格式选 BYTE**（1 字节/点）而非 ASCII（约 7 字节/点）→ 体积降 7 倍
2. **降低内存深度**。深度 20480 点 @250kSa/s → 约 4.4 fps；深度调小可到 7.5 fps
3. **只读需要的通道**。双通道比单通道慢接近一半
4. **不要重复读不变参数**（VDIV/OFST/TDIV），缓存起来，只在变化时重读
5. **FFT / 统计在电脑端算**，别让仪器算
6. 用 `:WAVeform:POINts:MODE NORMal` 只取屏幕点数，比 `RAW` 快
